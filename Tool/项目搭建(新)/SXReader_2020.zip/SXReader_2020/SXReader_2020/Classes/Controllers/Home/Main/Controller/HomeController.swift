//
//  HomeController.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/11/24.
//

import UIKit

class HomeController: UIBaseViewController {
    override var name: String {"首页"}
    
    let pageTitles = ["推荐", "听书", "课程", "书单"]
    let childControllers = [HomeRecommendController(),
                            HomeListenBookController(),
                            HomeCourseController(),
                            HomeBrilliantBookListController()]
    
    let mainColorTopView = UIImageView()
    
    let pageManager = FDMPageManager()
    let headerAnimation = FDMPageViewHeaderAnimation()
    
    let pageSearchView = FDMPageSearchHeaderView()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        createUI()
        createAction()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarHidden(true)
    }
}

//MARK: - UI
extension HomeController {
    func createUI() {
        self.view.addSubview(mainColorTopView)
        self.view.addSubview(pageManager.contentView)
        
        /* 顶部主颜色图片背景 */
        mainColorTopView.image = UIImage(named: "bg_HomeTopImage")
        mainColorTopView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(140 + FDMTool.statusHeight())
        }
        
        /* 分页控制器 */
        pageManager.titleHeight = 35
        pageManager.animationHeight = 18
        pageManager.contentView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(FDMTool.statusHeight() + 10)
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview().offset(-FDMTool.tabBarHeight())
        }
    }
}
 
