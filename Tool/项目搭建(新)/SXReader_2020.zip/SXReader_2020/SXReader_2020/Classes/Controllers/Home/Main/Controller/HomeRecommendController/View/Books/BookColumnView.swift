//
//  BookColumnView.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/24.
//

import UIKit

protocol BookColumnViewDelegate: NSObjectProtocol {
    /// 同学热读 - 点击书籍
    func clickHotReadingBook(_ model: BookInfoModel?)
    /// 新书上架 - 点击书籍
    func clickNewBookSaleBook(_ model: BookInfoModel?)
    /// 新书上架 - 查看更多
    func clickNewBookTitle()
}

//MARK: - 书籍模块
class BookColumnView: UIView {
    
    weak var delegate: BookColumnViewDelegate?
    
    let hotReadingView = HomeHotReadingView()
    var hotReadingModels: [BookInfoModel] { set { hotReadingView.setData(newValue) } get { hotReadingView.booksModel } }
    
    let newBooksSaleView = HomeNewBooksSaleView()
    var newBooksSaleModels: [BookInfoModel] { set { newBooksSaleView.setData(newValue) } get { newBooksSaleView.booksModel } }

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        createUI()
        createAction()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

//MARK: - UI
extension BookColumnView {
    
    func createUI(){
        self.addSubview(hotReadingView)
        self.addSubview(newBooksSaleView)
        
        /* 同学热读 */
        hotReadingView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(15)
            make.left.right.equalToSuperview()
        }
        
        /* 新书上架 */
        newBooksSaleView.snp.makeConstraints { (make) in
            make.top.equalTo(hotReadingView.snp.bottom).offset(15)
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview()
        }
    }
    
}

//MARK: - Action
extension BookColumnView {
    
    func createAction() {
        /* 同学热读 - 点击书籍 */
        hotReadingView.clickBookBlock = { [weak self] bookModel in
            self?.delegate?.clickHotReadingBook(bookModel)
        }
        
        /* 新书上架 - 点击书籍 */
        newBooksSaleView.clickBookBlock = { [weak self] bookModel in
            self?.delegate?.clickNewBookSaleBook(bookModel)
        }
        
        /* 新书上架 - 查看更多 */
        newBooksSaleView.clickTitleBlock = { [weak self] in
            self?.delegate?.clickNewBookTitle()
        }
    }
    
}
