//
//  HomeBrilliantBookListPresenter.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/11/30.
//

import UIKit

protocol HomeBrilliantBookListPresenterDelegate: BasePresenterListDelegate {
    /// 收到精彩书单列表数据
    func receivedBrilliantBookListsData(_ data: [HomeBrilliantBookListData])
}

//MARK: - 书单Presenter
class HomeBrilliantBookListPresenter: Presenter<HomeBrilliantBookListPresenterDelegate> {
    
    var listData = [HomeBrilliantBookListData]()
    
    /**
     刷新精彩书单列表
     */
    override func reloadData() {
        indexPage = 1
        requestData(isAppendData: false)
    }
    
    /**
     下一页数据
     */
    override func nextPageData() {
        indexPage += 1
        requestData(isAppendData: true)
    }
    
    /**
     网络请求
     */
    override func requestData(isAppendData: Bool) {
        
        // 模拟网络请求
        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [weak self] in
            // 1.判断数据是否请求成功，失败则通过全局弹窗进行提示
            
            // 2.判断数据是否需要拼接
            
            // 3.数据整合完毕调用协议方法
            self?.delegate?.receivedBrilliantBookListsData(self?.listData ?? [])
        }
    }
    
}
