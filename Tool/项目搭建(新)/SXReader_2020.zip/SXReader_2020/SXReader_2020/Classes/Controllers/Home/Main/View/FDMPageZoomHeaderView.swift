//
//  FDMPageZoomHeaderView.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/23.
//

import UIKit

class FDMPageZoomHeaderView: UIControl {
    
    let titleLabel = UILabel()
    let selectLabel = UILabel()

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        createUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

//MARK: - UI
extension FDMPageZoomHeaderView {
    func createUI() {
        self.addSubview(titleLabel)
        self.addSubview(selectLabel)
        
        /* titleLabel */
        titleLabel.font = UIFont.init(name: "PingFangSC-Regular", size: 16)
        titleLabel.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
        }
        
        /* selectLabel */
        selectLabel.alpha = 0
        selectLabel.font = UIFont.init(name: "PingFangSC-Medium", size: 16)
        selectLabel.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
        }
    }
}
