//
//  WorkListController+ActionExtension.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/1/4.
//

import UIKit

//MARK: - Action
extension WorkListController {
    func createAction() {
        /* 去除tableView下移 */
        if #available(iOS 11.0, *) { tableView.contentInsetAdjustmentBehavior = .never }
        if #available(iOS 13.0, *) { tableView.automaticallyAdjustsScrollIndicatorInsets = false }
    }
}


//MARK: - UITableViewDelegate, UITableViewDataSource
extension WorkListController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: WorkListCell.toString(), for: indexPath) as! WorkListCell
        
        cell.selectionStyle = .none
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let vc = WorkDetailsController(dynamicId: "")
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
