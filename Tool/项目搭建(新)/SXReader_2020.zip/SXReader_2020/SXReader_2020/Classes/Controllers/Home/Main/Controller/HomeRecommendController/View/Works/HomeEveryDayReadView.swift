//
//  HomeEveryDayReadView.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/24.
//

import UIKit

//MARK: - 首页每日一读
class HomeEveryDayReadView: UIControl {
    
    let timeBgView = UIView()
    let timeDayLabel = UILabel()
    let timeYearLabel = UILabel()
    let lunarCalendarLabel = UILabel()
    let titleLabel = UILabel()
    let rightArrowImgView = UIImageView()

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .Hex("#FBFBFB")
        
        createUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

//MARK: - UI
extension HomeEveryDayReadView {
    
    func createUI() {
        self.addSubview(timeBgView)
        self.timeBgView.addSubview(timeDayLabel)
        self.timeBgView.addSubview(timeYearLabel)
        self.addSubview(lunarCalendarLabel)
        self.addSubview(titleLabel)
        self.addSubview(rightArrowImgView)
        
        /* 时间背景 */
        timeBgView.layer.cornerRadius = 4
        timeBgView.backgroundColor = .Hex("#FAE16E")
        timeBgView.snp.makeConstraints { (make) in
            make.left.top.bottom.equalToSuperview()
            make.width.equalTo(timeBgView.snp.height)
        }
        
        /* 时间 - 日 */
        timeDayLabel.text = "26"
        timeDayLabel.setFontName("PingFangSC-Semibold", fontSize: 25, fontColor: .UsedHex333333())
        timeDayLabel.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview().offset(-10)
            make.centerX.equalToSuperview()
        }
        
        /* 时间 - 年月 */
        timeYearLabel.text = "2019.02"
        timeYearLabel.setFontName("PingFangSC-Regular", fontSize: 12, fontColor: .UsedHex333333())
        timeYearLabel.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.centerY.equalToSuperview().offset(20)
        }
        
        /* 时间 - 农历 */
        lunarCalendarLabel.text = "  正月初九  "
        lunarCalendarLabel.layer.cornerRadius = 3
        lunarCalendarLabel.layer.masksToBounds = true
        lunarCalendarLabel.backgroundColor = .Hex("#FF7843")
        lunarCalendarLabel.setFontName("PingFangSC-Medium", fontSize: 11, fontColor: .white)
        lunarCalendarLabel.snp.makeConstraints { (make) in
            make.left.equalTo(timeBgView.snp.right).offset(10)
            make.top.equalToSuperview().offset(15)
            make.height.equalTo(15)
        }
        
        /* 标题 */
        titleLabel.text = "人生得意须尽欢，莫使金樽空对月！"
        titleLabel.setFontName("PingFangSC-Regular", fontSize: 13, fontColor: .UsedHex333333())
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(timeBgView.snp.right).offset(10)
            make.right.lessThanOrEqualTo(rightArrowImgView.snp.left).offset(-10)
            make.bottom.equalToSuperview().offset(-10)
        }
        
        /* 箭头 */
        rightArrowImgView.image = UIImage(named: "icon_RightArrow")
        rightArrowImgView.snp.makeConstraints { (make) in
            make.right.equalToSuperview().offset(-10)
            make.centerY.equalToSuperview()
            make.width.equalTo(9)
            make.height.equalTo(11)
        }
    }
    
}

