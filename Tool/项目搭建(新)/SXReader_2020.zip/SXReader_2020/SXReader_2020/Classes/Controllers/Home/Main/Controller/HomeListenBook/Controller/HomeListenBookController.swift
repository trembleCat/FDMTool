//
//  HomeListenBookController.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/21.
//

import UIKit

class HomeListenBookController: UIBaseViewController {
    override var name: String { "听书" }
    
    let typeView = BookTypeView()
    let tableView = UITableView()
    
    lazy var typeSelectionView: HomeListenTypeSelectionView = {
        let contentView = HomeListenTypeSelectionView()
        self.view.addSubview(contentView)
        contentView.isHidden = true
        contentView.delegate = self
        contentView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview()
            make.top.equalTo(typeView.snp.bottom)
        }
        
        return contentView
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        createUI()
        createAction()
    }
}

//MARK: - UI
extension HomeListenBookController {
    func createUI() {
        self.view.addSubview(typeView)
        self.view.addSubview(tableView)
        
        /* 类型选择 */
        typeView.delegate = self
        typeView.snp.makeConstraints { (make) in
            make.left.top.right.equalToSuperview()
            make.height.equalTo(40)
        }

        /* 听书列表 */
        tableView.rowHeight = 124
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .none
        tableView.register(HomeListenBookCell.self, forCellReuseIdentifier: HomeListenBookCell.toString())
        tableView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalTo(typeView.snp.bottom)
            make.bottom.equalToSuperview()
        }
    }
}
