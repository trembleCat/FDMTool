//
//  WorkListCell.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/1/4.
//

import UIKit

//MARK: - 优秀作品列表
class WorkListCell: UIBaseTableViewCell {
    let workView = WorkViewItem()
    let lineSpacing = UIView()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        createUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

//MARK: - UI
extension WorkListCell {
    func createUI() {
        self.contentView.addSubview(workView)
        self.contentView.addSubview(lineSpacing)
        
        /* workView */
        workView.isUserInteractionEnabled = false
        workView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(15)
            make.left.equalToSuperview().offset(15)
            make.right.equalToSuperview().offset(-15)
            make.bottom.equalTo(lineSpacing.snp.top).offset(-15)
        }
        
        /* 分割线 */
        lineSpacing.backgroundColor = .UsedHexE8E8E8()
        lineSpacing.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview()
            make.height.equalTo(0.5)
        }
    }
}
