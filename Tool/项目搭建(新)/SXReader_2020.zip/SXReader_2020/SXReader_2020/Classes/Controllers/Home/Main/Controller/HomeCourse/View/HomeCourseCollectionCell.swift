//
//  HomeCourseCollectionCell.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/1/5.
//

import UIKit

//MARK: - 课程Cell
class HomeCourseCollectionCell: UIBaseCollectionViewCell {
    
    let videoImgView = UIImageView()
    let videoPlayerImgView = UIImageView()
    let titleLabel = UILabel()
    let subTitleLabel = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        createUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

//MARK: - UI
extension HomeCourseCollectionCell {
    func createUI() {
        self.contentView.addSubview(videoImgView)
        self.contentView.addSubview(videoPlayerImgView)
        self.contentView.addSubview(titleLabel)
        self.contentView.addSubview(subTitleLabel)
        
        /* 视频图片 */
        videoImgView.layer.cornerRadius = 4
        videoImgView.layer.masksToBounds = true
        videoImgView.backgroundColor = .Hex("#EDEDED")
        videoImgView.snp.makeConstraints { (make) in
            make.left.right.top.equalToSuperview()
            make.height.equalTo(90)
        }
        
        /* 视频播放按钮 */
        videoPlayerImgView.image = UIImage(named: "videoPlayer_Play")
        videoPlayerImgView.snp.makeConstraints { (make) in
            make.center.equalTo(videoImgView)
            make.size.equalTo(CGSize.init(width: 20, height: 24))
        }
        
        /* 主标题 */
        titleLabel.text = "带你走进《城南旧事》"
        titleLabel.setFontName("PingFangSC-Medium", fontSize: 14, fontColor: .UsedHex333333())
        titleLabel.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalTo(videoImgView.snp.bottom).offset(10)
        }
        
        /* 副标题 */
        subTitleLabel.text = "和林海音一起追忆童年"
        subTitleLabel.setFontName("PingFangSC-Regular", fontSize: 12, fontColor: .UsedHex999999())
        subTitleLabel.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalTo(titleLabel.snp.bottom).offset(5)
        }
    }
}
