//
//  WorksColumnView.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/24.
//

import UIKit

protocol WorksColumnViewDelegate: NSObjectProtocol {
    /// 点击开启伴读任务
    func clickTaskTipsView()
    
    /// 点击每日一读
    func clickEveryDayReadView()
    
    /// 点击优秀作品查看全部
    func clickWorksTitleView()
    
    /// 点击优秀作品
    func clickWorksView()
}

//MARK: - 作品模块
class WorksColumnView: UIView {
    
    weak var delegate: WorksColumnViewDelegate?
    
    let taskTipsView = UIView()
    let taskBgImgView = UIImageView()
    let taskYueYueImgView = UIImageView()
    let taskRightArrowImgView = UIImageView()
    let taskTitleLabel = UILabel()
    
    let everyDayReadTitleView = TitleHeaderView()
    let everyDayReadView = HomeEveryDayReadView()
    
    let worksTitleView = TitleHeaderView()
    let worksView = WorkViewItem()

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        createUI()
        createAction()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

//MARK: - UI
extension WorksColumnView {
    
    func createUI() {
        self.addSubview(taskTipsView)
        self.taskTipsView.addSubview(taskBgImgView)
        self.taskTipsView.addSubview(taskYueYueImgView)
        self.taskBgImgView.addSubview(taskRightArrowImgView)
        self.taskBgImgView.addSubview(taskTitleLabel)
        self.addSubview(everyDayReadTitleView)
        self.addSubview(everyDayReadView)
        self.addSubview(worksTitleView)
        self.addSubview(worksView)
        
        /* 任务提醒 */
        taskTipsView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(10)
            make.left.right.equalToSuperview()
            make.height.equalTo(75)
        }
        
        /* 任务背景 */
        taskBgImgView.image = UIImage(named: "bg_HomeTaskImage")
        taskBgImgView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(10)
            make.right.equalToSuperview().offset(-10)
            make.bottom.equalToSuperview()
            make.top.equalToSuperview()
        }
        
        /* 悦悦 */
        taskYueYueImgView.image = UIImage(named: "icon_YueYue")
        taskYueYueImgView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(15)
            make.top.equalToSuperview()
            make.bottom.equalToSuperview().offset(-5)
            make.width.equalTo(55)
        }
        
        /* 箭头 */
        taskRightArrowImgView.image = UIImage(named: "icon_TaskRightArrow")
        taskRightArrowImgView.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview().offset(10)
            make.right.equalToSuperview().offset(-23)
            make.width.equalTo(7)
            make.height.equalTo(8)
        }
        
        /* 任务标题 */
        taskTitleLabel.text = "同学，快来开启4月15日的伴读任务吧！"
        taskTitleLabel.setFontName("PingFangSC-Regular", fontSize: 14, fontColor: .UsedHex333333())
        taskTitleLabel.snp.makeConstraints { (make) in
            make.centerY.equalTo(taskRightArrowImgView)
            make.left.lessThanOrEqualTo(taskYueYueImgView.snp.right).offset(10)
            make.right.lessThanOrEqualTo(taskRightArrowImgView.snp.left).offset(-5)
        }
        
        /* 每日一读标题 */
        everyDayReadTitleView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(15)
            make.right.equalToSuperview().offset(-15)
            make.top.equalTo(taskTipsView.snp.bottom).offset(25)
        }
        
        /* 每日一读 */
        everyDayReadView.layer.cornerRadius = 4
        everyDayReadView.snp.makeConstraints { (make) in
            make.top.equalTo(everyDayReadTitleView.snp.bottom).offset(15)
            make.left.equalToSuperview().offset(15)
            make.right.equalToSuperview().offset(-15)
            make.height.equalTo(70)
        }
        
        /* 优秀作品标题 */
        worksTitleView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(15)
            make.right.equalToSuperview().offset(-20)
            make.top.equalTo(everyDayReadView.snp.bottom).offset(25)
        }
        
        /* 优秀作品 */
        worksView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(15)
            make.right.equalToSuperview().offset(-15)
            make.top.equalTo(worksTitleView.snp.bottom).offset(15)
            make.height.equalTo(120)
            make.bottom.equalToSuperview()
        }
    }
    
}

//MARK: - Action
extension WorksColumnView {
    
    func createAction() {
        
        /* 每日一读 */
        let everyDayString = NSMutableAttributedString(string: "每日一读")
        everyDayString.addFont(UIFont.init(name: "PingFangSC-Medium", size: 16)!)
        everyDayString.addForegroundColor(.UsedHex333333())
        
        everyDayReadTitleView.setTitle(everyDayString)
        
        /* 优秀作品 */
        let worksTitleString = NSMutableAttributedString(string: "优秀作品")
        worksTitleString.addFont(UIFont.init(name: "PingFangSC-Medium", size: 16)!)
        worksTitleString.addForegroundColor(.UsedHex333333())
        
        let worksSubTitleString = NSMutableAttributedString(string: "查看全部")
        worksSubTitleString.addFont(UIFont.init(name: "PingFangSC-Regular", size: 14)!)
        worksSubTitleString.addForegroundColor(.UsedHex999999())
        
        worksTitleView.setTitle(worksTitleString)
        worksTitleView.setSubTitle(worksSubTitleString, image: UIImage(named: "icon_WorksRightArrow"))
        
        /* 点击手势 - 开启伴读任务 */
        let taskTipsTapGesture = UITapGestureRecognizer(target: self, action: #selector(clickTaskTipsView))
        taskTipsView.addGestureRecognizer(taskTipsTapGesture)
        
        /* 点击手势 - 每日一读 */
        everyDayReadView.addTarget(self, action: #selector(clickEveryDayReadView), for: .touchUpInside)
        
        /* 点击手势 - 优秀作品查看全部 */
        worksTitleView.addSubTitleTarget(self, action: #selector(clickWorksTitleView))
        
        /* 点击手势 - 优秀作品 */
        worksView.addTarget(self, action: #selector(clickWorksView), for: .touchUpInside)
    }
    
    /**
     点击开启伴读任务
     */
    @objc func clickTaskTipsView() {
        self.delegate?.clickTaskTipsView()
    }
    
    /**
     点击每日一读
     */
    @objc func clickEveryDayReadView() {
        self.delegate?.clickEveryDayReadView()
    }
    
    /**
     点击优秀作品查看全部
     */
    @objc func clickWorksTitleView() {
        self.delegate?.clickWorksTitleView()
    }
    
    /**
     点击优秀作品
     */
    @objc func clickWorksView() {
        self.delegate?.clickWorksView()
    }
    
}
