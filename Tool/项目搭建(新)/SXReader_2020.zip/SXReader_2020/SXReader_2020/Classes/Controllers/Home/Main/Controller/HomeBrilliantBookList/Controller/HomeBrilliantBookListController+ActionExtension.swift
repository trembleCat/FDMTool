//
//  HomeBrilliantBookListController+ActionExtension.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/11/30.
//

import UIKit

//MARK: - Action
extension HomeBrilliantBookListController {
    func createAction() {
        
        /* 去除Tableview自动下移 */
        if #available(iOS 11.0, *) { tableView.contentInsetAdjustmentBehavior = .never }
        if #available(iOS 13.0, *) { tableView.automaticallyAdjustsScrollIndicatorInsets = false }
        
        /* 绑定presenter */
        presenter.bindPresenter(delegate: self)
        presenter.reloadData()
    }
}


//MARK: - UITableViewDataSource, UITableViewDelegate
extension HomeBrilliantBookListController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return listData.count
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: HomeBrilliantBookListCell.toString(), for: indexPath) as! HomeBrilliantBookListCell
        
        cell.selectionStyle = .none
        
//        cell.setModel(listData[indexPath.row])
        cell.titleLabel.text = "标题"
        cell.subLabel.text = "副标题"
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
//        039a6c25366811e891a0fa163e29292b
        // 书单详情
        let vc = BrilliantBookDetailsListController(dynamicId: "")
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
