//
//  CourseBookInfoView.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/1/11.
//

import UIKit

//MARK: - 课程关联书籍
class CourseBookInfoView: UIView {
    let spacingLine = UIView()
    let titleLabel = UILabel()
    let bookView = BookInfoView(isShowAbstract: false)

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        createUI()
        createAction()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

//MARK: - UI
extension CourseBookInfoView {
    func createUI() {
        self.addSubview(spacingLine)
        self.addSubview(titleLabel)
        self.addSubview(bookView)
        
        /* 分割线 */
        spacingLine.backgroundColor = .UsedHexE8E8E8()
        spacingLine.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalToSuperview().offset(3)
            make.height.equalTo(0.5)
        }
        
        /* 标题 */
        titleLabel.text = "关联书籍"
        titleLabel.setFontName("PingFangSC-Semibold", fontSize: 16, fontColor: .UsedHex333333())
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(14)
            make.top.equalTo(spacingLine.snp.bottom).offset(16)
            make.right.lessThanOrEqualToSuperview().offset(-14)
            make.bottom.equalToSuperview()
        }
        
        /* 书籍信息 */
        bookView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalTo(titleLabel.snp.bottom).offset(11)
            make.height.equalTo(114)
        }
    }
    
}

//MARK: - Action
extension CourseBookInfoView {
    func createAction() {
        bookView.setBookModel(BookInfoModel(JSONString: ""))
    }
}
