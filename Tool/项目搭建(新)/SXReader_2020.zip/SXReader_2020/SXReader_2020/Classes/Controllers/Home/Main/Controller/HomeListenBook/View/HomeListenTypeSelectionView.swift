//
//  HomeListenTypeSelectionView.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/1/6.
//

import UIKit

//MARK: - HomeListenTypeSelectionDelegate
protocol HomeListenTypeSelectionDelegate: NSObjectProtocol {
    /// 选中 Item 模型
    func selectedItemModel()
}

//MARK: - 首页听书类型选项
class HomeListenTypeSelectionView: UIView {
    
    weak var delegate: HomeListenTypeSelectionDelegate?
    
    let backdropView = UIControl()
    let collectionLayout = UICollectionViewFlowLayout()
    var collectionView: UICollectionView

    override init(frame: CGRect) {
        collectionView = UICollectionView(frame: .zero, collectionViewLayout: collectionLayout)
        super.init(frame: frame)
        
        createUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

//MARK: - UI + Action
extension HomeListenTypeSelectionView {
    func createUI() {
        self.addSubview(backdropView)
        self.backdropView.addSubview(collectionView)
        
        /* 浅色背景 */
        backdropView.backgroundColor = .Hex("#000000", alpha: 0.3)
        backdropView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        /* Layout */
        collectionLayout.minimumInteritemSpacing = 3

        collectionLayout.itemSize = .init(width: (FScreenW - 40) / 4, height: 33)
        collectionLayout.scrollDirection = .vertical
        
        /* collectionView */
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.backgroundColor = .white
        collectionView.contentInset = .init(top: 15, left: 10, bottom: 15, right: 10)
        collectionView.register(HomeListenTypeSelectionCell.self, forCellWithReuseIdentifier: HomeListenTypeSelectionCell.toString())
        collectionView.snp.makeConstraints { (make) in
            make.left.right.top.equalToSuperview()
            make.height.equalTo(240)
        }
    }
}

//MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension HomeListenTypeSelectionView: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 20
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: HomeListenTypeSelectionCell.toString(), for: indexPath) as! HomeListenTypeSelectionCell
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.reloadItems(at: [indexPath])
        delegate?.selectedItemModel()
    }
}
