//
//  HomeListenBookController+ActionExtension.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/1/6.
//

import UIKit

//MARK: - Action
extension HomeListenBookController {
    func createAction() {
        /* 去除Tableview自动下移 */
        if #available(iOS 11.0, *) { tableView.contentInsetAdjustmentBehavior = .never }
        if #available(iOS 13.0, *) { tableView.automaticallyAdjustsScrollIndicatorInsets = false }
    }
}


//MARK: - UITableViewDataSource, UITableViewDelegate
extension HomeListenBookController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: HomeListenBookCell.toString(), for: indexPath) as! HomeListenBookCell
        
        cell.selectionStyle = .none
        cell.setModel()
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = ListenBookDetailsController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

//MARK: - BookTypeViewDelegate,
extension HomeListenBookController: BookTypeViewDelegate, HomeListenTypeSelectionDelegate {
    func selectedItemModel() {
        typeView.setTitleName("全部")
    }
    
    func selectedTypeBtn(_ isShow: Bool, index: Int) {
        if isShow {
            typeSelectionView.isHidden = false
        }else {
            typeSelectionView.isHidden = true
        }
    }
}
