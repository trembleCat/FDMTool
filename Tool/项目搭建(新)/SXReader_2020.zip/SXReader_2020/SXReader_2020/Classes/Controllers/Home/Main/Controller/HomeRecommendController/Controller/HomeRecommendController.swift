//
//  HomeRecommendController.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/21.
//

import UIKit

class HomeRecommendController: UIBaseViewController {
    override var name: String { "推荐" }
    
    let scrollView = UIScrollView()
    let contentView = UIView()
    let contentBgColorView = UIView()
    
    let newsColumnView = NewsColumnView()
    let worksColumnView = WorksColumnView()
    let bookColumnView = BookColumnView()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .clear
        
        createUI()
        createAction()
    }
}

//MARK: - UI
extension HomeRecommendController {
    func createUI() {
        self.view.addSubview(scrollView)
        self.scrollView.addSubview(contentView)
        self.contentView.addSubview(contentBgColorView)
        self.contentView.addSubview(newsColumnView)
        self.contentView.addSubview(worksColumnView)
        self.contentView.addSubview(bookColumnView)
        
        /* scrollView */
        scrollView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        /* contentView */
        contentView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
            make.width.equalTo(FScreenW)
        }
        
        /* contentBgColorView */
        contentBgColorView.backgroundColor = .white
        contentBgColorView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(85)
            make.left.right.bottom.equalToSuperview()
        }
        
        /* 新闻栏 */
        newsColumnView.delegate = self
        newsColumnView.bannerDelegate = self
        newsColumnView.snp.makeConstraints { (make) in
            make.left.right.top.equalToSuperview()
        }
        
        /* 作品栏 */
        worksColumnView.delegate = self
        worksColumnView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalTo(newsColumnView.snp.bottom)
        }
        
        /* 书籍栏 */
        bookColumnView.delegate = self
        bookColumnView.snp.makeConstraints { (make) in
            make.left.bottom.right.equalToSuperview()
            make.top.equalTo(worksColumnView.snp.bottom)
        }
    }
}
