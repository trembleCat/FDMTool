//
//  EveryDayReadContentView.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/10.
//

import UIKit

//MARK: - 每日一读内容视图
class EveryDayReadContentView: UIView {
    
    let imageView = UIImageView()
    
    let titleLabel = UILabel()
    let contentLabel = UILabel()
    
    let recommendBtn = UIButton()
    let unRecommendBtn = UIButton()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        createUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

//MARK: - UI
extension EveryDayReadContentView {
    func createUI() {
        self.addSubview(imageView)
        self.addSubview(titleLabel)
        self.addSubview(contentLabel)
        self.addSubview(recommendBtn)
        self.addSubview(unRecommendBtn)
        
        /* 背景图片 */
        imageView.contentMode = .scaleToFill
        imageView.snp.makeConstraints { (make) in
            make.top.left.right.bottom.equalToSuperview()
        }
        
        /* 标题 */
        titleLabel.numberOfLines = 3
        titleLabel.setFontName("PingFangSC-Medium", fontSize: 20, fontColor: .UsedHex333333())
        titleLabel.textAlignment = .center
        titleLabel.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(15)
            make.left.equalToSuperview().offset(50)
            make.right.equalToSuperview().offset(-50)
        }

        /* 内容 */
        contentLabel.numberOfLines = 0
        contentLabel.snp.makeConstraints { (make) in
            make.top.equalTo(titleLabel.snp.bottom).offset(20)
            make.left.equalToSuperview().offset(25)
            make.right.equalToSuperview().offset(-25)
        }

        /* 推荐按钮 */
        recommendBtn.setImage(UIImage(named: "icon_Recommend"), for: .normal)
        recommendBtn.titleLabel?.font = UIFont.init(name: "PingFangSC-Medium", size: 14)
        recommendBtn.setTitleColor(.UsedHex333333(), for: .normal)
        recommendBtn.layer.cornerRadius = 18
        recommendBtn.layer.borderWidth = 1
        recommendBtn.layer.borderColor = .Hex("#979797")
        recommendBtn.snp.makeConstraints { (make) in
            make.top.equalTo(contentLabel.snp.bottom).offset(40)
            make.centerX.equalToSuperview().offset(-75)
            make.size.equalTo(CGSize.init(width: 76, height: 36))
            make.bottom.equalToSuperview().offset(-20)
        }

        /* 不推荐按钮 */
        unRecommendBtn.setImage(UIImage(named: "icon_UnRecommend"), for: .normal)
        unRecommendBtn.titleLabel?.font = UIFont.init(name: "PingFangSC-Medium", size: 14)
        unRecommendBtn.setTitleColor(.UsedHex333333(), for: .normal)
        unRecommendBtn.layer.cornerRadius = 18
        unRecommendBtn.layer.borderWidth = 1
        unRecommendBtn.layer.borderColor = .Hex("#979797")
        unRecommendBtn.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview().offset(75)
            make.centerY.equalTo(recommendBtn)
            make.size.equalTo(recommendBtn)
        }
    }
}

//MARK: - Action
extension EveryDayReadContentView {
    
    /**
     设置背景图片
     */
    func setBackgroundImage(_ image: UIImage?) {
        self.imageView.image = image
    }
    
    /**
     设置内容数据
     */
    func setContent(_ data: EveryDayReadData?) {
        titleLabel.text = "一片垃圾的旅程"
        recommendBtn.setTitle(" 120", for: .normal)
        unRecommendBtn.setTitle(" 120", for: .normal)

        let attrs = NSMutableAttributedString(string: "    亨德森岛是一处位于太平洋中央荒无人烟的小岛，距离人口密集区足足3000英里。尽管它的面积只有曼哈顿的一半大小，但在沙滩上却囤积了约19吨废弃的垃圾。\n    据研究者估算，亨德森岛是世界上垃圾碎片最密集的地域，在这片小小的人迹罕至的岛屿上散落着约3700万片废弃物的残骸。倘若你漫步在这座岛上，你所踏足的每一平方米土地都有约672片垃圾。每看到一片散落在沙滩表面的垃圾，就会有另外两片埋在沙子里。\n    这么多的废弃物究竟是怎么被冲上这个岛屿的呢？让我们从废弃物在陆地上的处理方式说起。  \n    处理不当的塑料废品——即那些不论有意还是无意，没有以正确方式回收的塑料废品——在一些缺少多样化废品回收系统将其输送到处理中心或填埋地点的发展中国家尤其多见。")
        attrs.addFont(UIFont.init(name: "PingFangSC-Regular", size: 15)!)
        attrs.addForegroundColor(.Hex("#505050"))
        contentLabel.attributedText = attrs
    }
}
