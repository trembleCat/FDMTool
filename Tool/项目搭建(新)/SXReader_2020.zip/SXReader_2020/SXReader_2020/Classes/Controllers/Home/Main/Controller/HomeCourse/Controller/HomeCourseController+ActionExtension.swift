//
//  HomeCourseController+ActionExtension.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/1/5.
//

import UIKit

//MARK: - Action
extension HomeCourseController {
    func createAction() {
        /* 去除Tableview自动下移 */
        if #available(iOS 11.0, *) { collectionView.contentInsetAdjustmentBehavior = .never }
        if #available(iOS 13.0, *) { collectionView.automaticallyAdjustsScrollIndicatorInsets = false }
    }
}


//MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension HomeCourseController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 2
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 4
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: HomeCourseCollectionCell.toString(), for: indexPath) as! HomeCourseCollectionCell
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let vc = CourseDetailsController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        
        return CGSize(width: 0, height: 35)
    }
    
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        
        let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: collectionHeaderId, for: indexPath) as! HomeCourseHeaderReusableView
        
        if indexPath.section == 0 {
            headerView.showLineSpacing(false)
            headerView.setTitle("精品课程")
            headerView.clickSubTitleBlock = { [weak self] in
                FLog(title: "点击精品课程", message: "查看更多")
            }
            
        }else if indexPath.section == 1 {
            headerView.showLineSpacing(true)
            headerView.setTitle("精彩导读")
            headerView.clickSubTitleBlock = { [weak self] in
                FLog(title: "点击精彩导读", message: "查看更多")
            }
            
        }
        
        return headerView
    }
}
