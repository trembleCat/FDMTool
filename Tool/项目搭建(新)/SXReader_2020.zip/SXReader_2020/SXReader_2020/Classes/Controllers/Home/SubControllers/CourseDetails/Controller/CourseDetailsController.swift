//
//  CourseDetailsController.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/1/11.
//

import UIKit

class CourseDetailsController: UIBaseViewController {
    override var name: String {"课程详情"}
    override var prefersStatusBarHidden: Bool { isHiddenStatusBar }
    
    var isHiddenStatusBar = false
    
    let scrollView = UIScrollView()
    let contentView = UIView()
    let playerView = CoursePlayerView()
    let contentInfoView = CourseContentInfoView()
    let bookInfoView = CourseBookInfoView()
    let backBtn = UIButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        createUI()
        createAction()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.setNavigationBarHidden(true)
    }
}

//MARK: - UI
extension CourseDetailsController {
    func createUI() {
        self.view.addSubview(scrollView)
        self.scrollView.addSubview(contentView)
        self.contentView.addSubview(playerView)
        self.contentView.addSubview(contentInfoView)
        self.contentView.addSubview(bookInfoView)
        self.contentView.addSubview(backBtn)
        
        /* scrollView */
        scrollView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        /* contentView */
        contentView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
            make.width.equalTo(FScreenW)
        }
        
        /* 播放器 */
        playerView.snp.makeConstraints { (make) in
            make.left.top.right.equalToSuperview()
            make.height.equalTo(210 + FDMTool.statusHeight())
        }
        
        /* 内容详情 */
        contentInfoView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalTo(playerView.snp.bottom)
        }
        
        /* 关联书籍 */
        bookInfoView.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalTo(contentInfoView.snp.bottom)
            make.bottom.equalToSuperview()
        }
        
        /* 返回按钮 */
        backBtn.setImage(UIImage(named: "icon_Back"), for: .normal)
        backBtn.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(20)
            make.top.equalToSuperview().offset(FDMTool.statusHeight() + 5)
            make.width.equalTo(22)
            make.height.equalTo(25)
        }
    }
}
