//
//  HomeRecommendController+ActionExtension.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/24.
//

import UIKit

//MARK: - Action
extension HomeRecommendController {
    func createAction() {
        /* 去除Tableview自动下移 */
        if #available(iOS 11.0, *) { scrollView.contentInsetAdjustmentBehavior = .never }
        if #available(iOS 13.0, *) { scrollView.automaticallyAdjustsScrollIndicatorInsets = false }
    }
}

//MARK: - NewsColumnViewDelegate - 新闻栏点击代理
extension HomeRecommendController: NewsColumnViewDelegate {
    
    func clickClockBtn() {
        
    }
    
    func clickShopBtn() {
        
    }
    
    func clickBooksBtn() {
        
    }
    
    func clickCollectionBtn() {
        
    }
}


//MARK: - WorksColumnViewDelegate - 作品栏点击代理
extension HomeRecommendController: WorksColumnViewDelegate {
    
    func clickTaskTipsView() {
        
    }
    
    func clickEveryDayReadView() {
        let vc = EveryDayReadController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func clickWorksTitleView() {
        let vc = WorkListController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func clickWorksView() {
        let vc = WorkDetailsController(dynamicId: "")
        self.navigationController?.pushViewController(vc, animated: true)
    }
}


//MARK: - BookColumnViewDelegate - 书籍栏点击代理
extension HomeRecommendController: BookColumnViewDelegate {
    
    func clickHotReadingBook(_ model: BookInfoModel?) {
        // 暂时使用假数据
        let vc = BookDetailsController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func clickNewBookSaleBook(_ model: BookInfoModel?) {
        // 暂时使用假数据
        let vc = BookDetailsController()
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    func clickNewBookTitle() {
        
    }
}


//MARK: - FDMBannerViewDelegate - Banner点击代理
extension HomeRecommendController: FDMBannerViewDelegate {
    func bannerView(_ imageView: UIImageView, url: String?) {
        
    }
    
    func bannerView(didSelectItemAt indexPath: IndexPath) {
        
    }
}
