//
//  WorkListController.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/1/4.
//

import UIKit

class WorkListController: UIBaseViewController {
    override var name: String {"优秀作品"}
    
    let tableView = UITableView()

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.title = name
        
        createUI()
        createAction()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setNavigationBarHidden(false)
    }
}

//MARK: - UI
extension WorkListController {
    func createUI() {
        self.view.addSubview(tableView)
        
        /* tableView */
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorStyle = .none
        tableView.rowHeight = 145
        tableView.contentInset = .init(top: 5, left: 0, bottom: 0, right: 0)
        tableView.register(WorkListCell.self, forCellReuseIdentifier: WorkListCell.toString())
        tableView.snp.makeConstraints { (make) in
            make.left.right.top.equalToSuperview()
            make.bottom.equalToSuperview().offset(-FDMTool.bottomSafeHeight())
        }
    }
}
