//
//  NewsColumnView.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/24.
//

import UIKit

protocol NewsColumnViewDelegate: NSObjectProtocol {
    /// 点击阅读打卡
    func clickClockBtn()
    
    /// 点击星币商城
    func clickShopBtn()
    
    /// 点击全部图书
    func clickBooksBtn()
    
    /// 点击我的收藏
    func clickCollectionBtn()
}


//MARK: - 新闻模块
class NewsColumnView: UIView {
    
    weak var delegate: NewsColumnViewDelegate?
    weak var bannerDelegate: FDMBannerViewDelegate? { didSet { bannerManager.delegate = bannerDelegate } }
    
    let bgView = UIView()
    let bannerManager = FDMBannerManager()
    let bannerTagView = FDMBannerNormalTagView()
    
    let stackView = UIStackView()
    let clockBtn = FDMCustomButton()
    let shopBtn = FDMCustomButton()
    let booksBtn = FDMCustomButton()
    let collectionBtn = FDMCustomButton()
    
    let dividingLineView = UIView()

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        createUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

//MARK: - UI
extension NewsColumnView {
    
    func createUI() {
        self.addSubview(bgView)
        self.addSubview(bannerManager.contentView)
        self.addSubview(stackView)
        self.addSubview(dividingLineView)
        
        /* 背景 */
        bgView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(35)
            make.left.right.bottom.equalToSuperview()
        }
        
        /* 轮播图 */
//        bannerManager.type = .UrlImage
//        bannerManager.urlImageArray = []
        bannerManager.radius = 8
        bannerManager.rollingTime = 5000
        bannerManager.horizontalSpacing = 15
        bannerManager.progressDelegate = bannerTagView
        bannerManager.imageArray = [UIColor.red.toImage(), UIColor.orange.toImage(), UIColor.blue.toImage()]
        bannerManager.contentView.snp.makeConstraints { (make) in
            make.left.right.top.equalToSuperview()
            make.height.equalTo(144)
        }
        
        /* 分割线 */
        dividingLineView.backgroundColor = .backgroundPrimaryDark()
        dividingLineView.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(10)
        }
        
        createStackView()
    }
    
    /**
     创建
     */
    func createStackView() {
        /* 阅读打卡 */
        clockBtn.imageSpacing = 8
        clockBtn.imagePosition = .FDMButtomImageTop
        clockBtn.setTitle("阅读打卡", for: .normal)
        clockBtn.setTitleColor(.UsedHex333333(), for: .normal)
        clockBtn.setImage(UIImage(named: "icon_Clock"), for: .normal)
        clockBtn.titleLabel?.font = UIFont.init(name: "PingFangSC-Regular", size: 12)
        clockBtn.addTarget(self, action: #selector(clickClockBtn), for: .touchUpInside)
        
        /* 星币商城 */
        shopBtn.imageSpacing = 8
        shopBtn.imagePosition = .FDMButtomImageTop
        shopBtn.setTitle("星币商城", for: .normal)
        shopBtn.setTitleColor(.UsedHex333333(), for: .normal)
        shopBtn.setImage(UIImage(named: "icon_Shop"), for: .normal)
        shopBtn.titleLabel?.font = UIFont.init(name: "PingFangSC-Regular", size: 12)
        shopBtn.addTarget(self, action: #selector(clickShopBtn), for: .touchUpInside)
        
        /* 全部图书 */
        booksBtn.imageSpacing = 8
        booksBtn.imagePosition = .FDMButtomImageTop
        booksBtn.setTitle("全部图书", for: .normal)
        booksBtn.setTitleColor(.UsedHex333333(), for: .normal)
        booksBtn.setImage(UIImage(named: "icon_Books"), for: .normal)
        booksBtn.titleLabel?.font = UIFont.init(name: "PingFangSC-Regular", size: 12)
        booksBtn.addTarget(self, action: #selector(clickBooksBtn), for: .touchUpInside)
        
        /* 我的收藏 */
        collectionBtn.imageSpacing = 8
        collectionBtn.imagePosition = .FDMButtomImageTop
        collectionBtn.setTitle("我的收藏", for: .normal)
        collectionBtn.setTitleColor(.UsedHex333333(), for: .normal)
        collectionBtn.setImage(UIImage(named: "icon_Collection"), for: .normal)
        collectionBtn.titleLabel?.font = UIFont.init(name: "PingFangSC-Regular", size: 12)
        collectionBtn.addTarget(self, action: #selector(clickCollectionBtn), for: .touchUpInside)
        
        stackView.insertArrangedSubview(collectionBtn, at: 0)
        stackView.insertArrangedSubview(booksBtn, at: 0)
        stackView.insertArrangedSubview(shopBtn, at: 0)
        stackView.insertArrangedSubview(clockBtn, at: 0)
        stackView.alignment = .fill
        stackView.axis = .horizontal
        stackView.distribution = .fillEqually
        
        stackView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(15)
            make.right.equalToSuperview().offset(-15)
            make.top.equalTo(bannerManager.contentView.snp.bottom).offset(10)
            make.bottom.equalTo(dividingLineView.snp.top).offset(-10)
            make.height.equalTo(80)
        }
    }
    
}

//MARK: - Action
extension NewsColumnView {
    
    /**
     点击阅读打卡
     */
    @objc func clickClockBtn() {
        self.delegate?.clickClockBtn()
    }
    
    /**
     点击星币商城
     */
    @objc func clickShopBtn() {
        self.delegate?.clickShopBtn()
    }
    
    /**
     点击全部图书
     */
    @objc func clickBooksBtn() {
        self.delegate?.clickBooksBtn()
    }
    
    /**
     点击我的收藏
     */
    @objc func clickCollectionBtn() {
        self.delegate?.clickCollectionBtn()
    }
    
}
