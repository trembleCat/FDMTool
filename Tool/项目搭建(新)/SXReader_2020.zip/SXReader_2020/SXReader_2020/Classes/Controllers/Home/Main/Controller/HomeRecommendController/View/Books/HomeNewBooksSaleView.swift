//
//  HomeNewBooksSaleView.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/25.
//

import UIKit

//MARK: - 新书上架
class HomeNewBooksSaleView: UIView {
    
    /// 点击书籍Item回调
    var clickBookBlock: ((BookInfoModel?) -> ())?
    /// 点击查看更多回调
    var clickTitleBlock: (() -> ())?
    
    var booksModel = [BookInfoModel]()

    let titleView = TitleHeaderView()
    let collectionLayout = UICollectionViewFlowLayout()
    var booksCollectionView: UICollectionView!

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        booksCollectionView = UICollectionView(frame: .zero, collectionViewLayout: collectionLayout)
        
        createUI()
        createAction()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

//MARK: - UI
extension HomeNewBooksSaleView {
    
    func createUI() {
        self.addSubview(titleView)
        self.addSubview(booksCollectionView)
        
        /* 标题 */
        titleView.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.left.equalToSuperview().offset(15)
            make.right.equalToSuperview().offset(-20)
        }
        
        /* collectionView */
        collectionLayout.scrollDirection = .vertical
        collectionLayout.minimumLineSpacing = 15
        collectionLayout.itemSize = .init(width: 85, height: 160)
        booksCollectionView.delegate = self
        booksCollectionView.dataSource = self
        booksCollectionView.backgroundColor = .clear
        booksCollectionView.showsHorizontalScrollIndicator = false
        booksCollectionView.showsHorizontalScrollIndicator = false
        booksCollectionView.isScrollEnabled = false
        booksCollectionView.register(BookCollectionViewCell.self, forCellWithReuseIdentifier: BookCollectionViewCell.toString())
        booksCollectionView.snp.makeConstraints { (make) in
            make.top.equalTo(titleView.snp.bottom).offset(15)
            make.left.equalToSuperview().offset(15)
            make.right.equalToSuperview().offset(-15)
            make.bottom.equalToSuperview().offset(-10)
            make.height.equalTo(350)
        }
    }
    
}

//MARK: - Action
extension HomeNewBooksSaleView {
    
    func createAction() {
        /* 设置标题 */
        let titleString = NSMutableAttributedString(string: "新书上架")
        titleString.addFont(UIFont.init(name: "PingFangSC-Medium", size: 16)!)
        titleString.addForegroundColor(.UsedHex333333())
        
        let subTitleString = NSMutableAttributedString(string: "查看全部")
        subTitleString.addFont(UIFont.init(name: "PingFangSC-Regular", size: 14)!)
        subTitleString.addForegroundColor(.UsedHex999999())
        
        titleView.setTitle(titleString)
        titleView.setSubTitle(subTitleString, image: UIImage(named: "icon_WorksRightArrow"))
        titleView.addSubTitleTarget(self, action: #selector(clickTitleView))
    }
    
    func setData(_ models: [BookInfoModel]) {
        self.booksModel = models
        self.booksCollectionView.reloadData()
    }
    
    /**
     点击查看更多
     */
    @objc private func clickTitleView() {
        self.clickTitleBlock?()
    }
    
}

//MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension HomeNewBooksSaleView: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 6
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: BookCollectionViewCell.toString(), for: indexPath) as! BookCollectionViewCell
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
//        self.clickBookBlock?(booksModel[indexPath.row])   数组暂时没有数据，关闭该功能
        self.clickBookBlock?(BookInfoModel(JSONString: "")) // 数据暂时没有，返回假数据
    }
    
}
