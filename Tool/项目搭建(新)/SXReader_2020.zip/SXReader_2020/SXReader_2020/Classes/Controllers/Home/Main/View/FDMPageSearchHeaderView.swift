//
//  FDMPageSearchHeaderView.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/25.
//

import UIKit

//MARK: - 首页搜索导航
class FDMPageSearchHeaderView: UIControl {
    
    let searchBgView = UIView()
    let searchImgView = UIImageView()
    let searchLabel = UILabel()

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        createUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

//MARK: - UI
extension FDMPageSearchHeaderView {
    
    func createUI() {
        self.addSubview(searchBgView)
        self.searchBgView.addSubview(searchImgView)
        self.searchBgView.addSubview(searchLabel)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        /* 背景 */
        searchBgView.backgroundColor = .white
        searchBgView.layer.cornerRadius = self.height / 2
        searchBgView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(10)
            make.right.equalToSuperview().offset(-10)
            make.top.bottom.equalToSuperview()
        }
        
        /* 搜索图片 */
        searchImgView.image = UIImage(named: "icon_PageSearch")
        searchImgView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(12)
            make.centerY.equalToSuperview()
            make.width.height.equalTo(15)
        }
        
        /* 标题 */
        searchLabel.text = "书名/作者名"
        searchLabel.setFontName("PingFangSC-Regular", fontSize: 12, fontColor: .UsedHex999999())
        searchLabel.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.left.equalTo(searchImgView.snp.right).offset(10)
            make.right.equalToSuperview().offset(-12)
        }
    }
}
