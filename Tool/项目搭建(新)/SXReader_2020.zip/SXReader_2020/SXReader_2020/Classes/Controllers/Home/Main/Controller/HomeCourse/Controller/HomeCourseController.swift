//
//  HomeCourseController.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/21.
//

import UIKit

class HomeCourseController: UIBaseViewController {
    override var name: String { "课程" }
    
    let collectionHeaderId = "collectionHeaderId"
    
    let collectionLayout = UICollectionViewFlowLayout()
    var collectionView: UICollectionView
    
    init() {
        self.collectionView = UICollectionView(frame: .zero, collectionViewLayout: collectionLayout)
        super.init(nibName: nil, bundle: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        createUI()
        createAction()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

//MARK: - UI
extension HomeCourseController {
    func createUI() {
        self.view.addSubview(collectionView)
        
        /* collectionLayout */
        collectionLayout.minimumInteritemSpacing = 10
        collectionLayout.minimumLineSpacing = 10
        collectionLayout.itemSize = .init(width: (FScreenW - 50) / 2, height: 140)
        collectionLayout.scrollDirection = .vertical
        collectionLayout.sectionInset = .init(top: 15, left: 15, bottom: 20, right: 15)
        
        /* collectionView */
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.backgroundColor = .clear
        collectionView.register(HomeCourseCollectionCell.self, forCellWithReuseIdentifier: HomeCourseCollectionCell.toString())
        collectionView.register(HomeCourseHeaderReusableView.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: collectionHeaderId)
        collectionView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
    }
}
