//
//  CourseContentInfoView.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/1/11.
//

import UIKit

//MARK: - 课程内容信息
class CourseContentInfoView: UIView {
    
    let titleLabel = UILabel()
    let contentLabel = UILabel()
    let nameLabel = UILabel()
    let timeLabel = UILabel()
    
    let nameText = "授课老师   "
    let timeText = "授课时间   "

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        createUI()
        createAction()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}


//MARK: - UI
extension CourseContentInfoView {
    func createUI() {
        self.addSubview(titleLabel)
        self.addSubview(contentLabel)
        self.addSubview(nameLabel)
        self.addSubview(timeLabel)
        
        /* 标题 */
        titleLabel.numberOfLines = 2
        titleLabel.text = "钱钟书先生经典著作解读《围城》"
        titleLabel.setFontName("PingFangSC-Medium", fontSize: 16, fontColor: .UsedHex333333())
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(18)
            make.right.equalToSuperview().offset(-18)
            make.top.equalToSuperview().offset(25)
        }
        
        /* 内容 */
        contentLabel.text = "这是钱钟书先生一生中唯一的一部长篇小说，堪称中国近代小说的经典，读起来回味无穷，妙趣横生。这本书前半部是理想，后半部是现实，加起来就是人生。主人公方鸿渐回到国内，历经从得意到困扰，进而在百般挣扎后落入婚姻围城的全过程。"
        contentLabel.numberOfLines = 0
        contentLabel.setFontName("PingFangSC-Regular", fontSize: 13, fontColor: .UsedHex999999())
        contentLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(18)
            make.right.equalToSuperview().offset(-18)
            make.top.equalTo(titleLabel.snp.bottom).offset(12)
        }
        
        /* 授课老师 */
        nameLabel.text = nameText
        nameLabel.setFontName("PingFangSC-Medium", fontSize: 14, fontColor: .UsedHex333333())
        nameLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(18)
            make.top.equalTo(contentLabel.snp.bottom).offset(20)
            make.right.lessThanOrEqualToSuperview().offset(-18)
        }
        
        /* 授课时间 */
        timeLabel.text = timeText
        timeLabel.setFontName("PingFangSC-Medium", fontSize: 14, fontColor: .UsedHex333333())
        timeLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(18)
            make.top.equalTo(nameLabel.snp.bottom).offset(20)
            make.right.lessThanOrEqualToSuperview().offset(-18)
            make.bottom.equalToSuperview().offset(-25)
        }
        
    }
}

//MARK: - Action
extension CourseContentInfoView {
    func createAction() {
        nameLabel.attributedText = getAttrs(nameText, subText: "郑伊萌")
        timeLabel.attributedText = getAttrs(timeText, subText: "2020年05月29日")
    }
    
    /**
     获取AttrsLabel
     */
    func getAttrs(_ titleText: String, subText: String) -> NSMutableAttributedString {
        let attrs = NSMutableAttributedString(string: titleText + subText)
        attrs.addFont(UIFont(name: "PingFangSC-Medium", size: 14) ?? .systemFont(ofSize: 14), range: .init(location: 0, length: titleText.count))
        attrs.addFont(UIFont(name: "PingFangSC-Regular", size: 14) ?? .systemFont(ofSize: 14), range: .init(location: titleText.count, length: attrs.length - titleText.count))
        
        attrs.addForegroundColor(.UsedHex333333(), range: .init(location: 0, length: titleText.count))
        attrs.addForegroundColor(.UsedHex666666(), range: .init(location: titleText.count, length: attrs.length - titleText.count))
        
        return attrs
    }
}
