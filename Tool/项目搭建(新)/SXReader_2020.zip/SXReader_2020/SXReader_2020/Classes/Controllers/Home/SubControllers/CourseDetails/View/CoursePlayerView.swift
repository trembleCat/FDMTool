//
//  CoursePlayerView.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/1/11.
//

import UIKit

//MARK: - 课程播放器View
class CoursePlayerView: UIView {

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .Hex("#EDEDED")
        
        createUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

//MARK: - UI
extension CoursePlayerView {
    func createUI() {
        
    }
}
