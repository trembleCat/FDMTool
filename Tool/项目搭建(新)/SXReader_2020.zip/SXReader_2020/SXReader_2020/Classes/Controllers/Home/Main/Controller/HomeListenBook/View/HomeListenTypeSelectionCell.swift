//
//  HomeListenTypeSelectionCell.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/1/6.
//

import UIKit

//MARK: - 听书类型选择Cell
class HomeListenTypeSelectionCell: UIBaseCollectionViewCell {
    
    let backdropView = UIView()
    let titleLabel = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        createUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}


//MARK: - UI
extension HomeListenTypeSelectionCell {
    func createUI() {
        self.contentView.addSubview(backdropView)
        self.backdropView.addSubview(titleLabel)
        
        /* 背景 */
        backdropView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        /* 标题 */
        titleLabel.text = "全部"
        titleLabel.textAlignment = .center
        titleLabel.setFontName("PingFangSC-Regular", fontSize: 12, fontColor: .UsedHex666666())
        titleLabel.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        backdropView.layer.cornerRadius = self.height * 0.5
        backdropView.backgroundColor = isSelected ? .mainColor() : .Hex("#F6F6F6")
    }
}
