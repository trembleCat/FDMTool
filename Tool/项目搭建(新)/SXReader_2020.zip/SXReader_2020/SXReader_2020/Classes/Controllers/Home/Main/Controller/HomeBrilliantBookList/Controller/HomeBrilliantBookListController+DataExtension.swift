//
//  HomeBrilliantBookListController+DataExtension.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/11/30.
//

import UIKit

//MARK: - Data
extension HomeBrilliantBookListController: HomeBrilliantBookListPresenterDelegate {
    
    func receivedBrilliantBookListsData(_ listData: [HomeBrilliantBookListData]) {
        self.listData = listData
        FLog(title: "数据请求成功", message: "")
    }
    
    func requestWillBegin() {
        
    }
    
    func requestDidEnd() {
        
    }
    
    func listEndPage() {
        
    }
}
