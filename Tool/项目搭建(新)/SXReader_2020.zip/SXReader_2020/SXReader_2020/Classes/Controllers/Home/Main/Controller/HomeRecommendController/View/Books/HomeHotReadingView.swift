//
//  HomeHotReadingView.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/24.
//

import UIKit

//MARK: - 同学热读
class HomeHotReadingView: UIView {
    
    /// 点击书籍Item回调
    var clickBookBlock: ((BookInfoModel?) -> ())?
    var booksModel = [BookInfoModel]()

    let titleView = TitleHeaderView()
    let collectionLayout = UICollectionViewFlowLayout()
    var booksCollectionView: UICollectionView!

    override init(frame: CGRect) {
        super.init(frame: frame)
        booksCollectionView = UICollectionView(frame: .zero, collectionViewLayout: collectionLayout)
        
        createUI()
        createAction()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

//MARK: - UI
extension HomeHotReadingView {
    
    func createUI() {
        self.addSubview(titleView)
        self.addSubview(booksCollectionView)
        
        /* 标题 */
        titleView.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.left.equalToSuperview().offset(15)
            make.right.equalToSuperview().offset(-15)
        }
        
        /* collectionView */
        collectionLayout.scrollDirection = .horizontal
        collectionLayout.minimumInteritemSpacing = 15
        collectionLayout.itemSize = .init(width: 85, height: 160)
        booksCollectionView.delegate = self
        booksCollectionView.dataSource = self
        booksCollectionView.backgroundColor = .clear
        booksCollectionView.showsHorizontalScrollIndicator = false
        booksCollectionView.showsHorizontalScrollIndicator = false
        booksCollectionView.register(BookCollectionViewCell.self, forCellWithReuseIdentifier: BookCollectionViewCell.toString())
        booksCollectionView.contentInset = .init(top: 0, left: 15, bottom: 0, right: 15)
        booksCollectionView.snp.makeConstraints { (make) in
            make.top.equalTo(titleView.snp.bottom).offset(15)
            make.left.equalToSuperview()
            make.right.equalToSuperview()
            make.bottom.equalToSuperview().offset(-10)
            make.height.equalTo(160)
        }
    }
    
}

//MARK: - Action
extension HomeHotReadingView {
    
    func createAction() {
        /* 设置标题 */
        let titleString = NSMutableAttributedString(string: "同学热读")
        titleString.addFont(UIFont.init(name: "PingFangSC-Medium", size: 16)!)
        titleString.addForegroundColor(.UsedHex333333())
        
        titleView.setTitle(titleString)
    }
    
    func setData(_ models: [BookInfoModel]) {
        self.booksModel = models
        self.booksCollectionView.reloadData()
    }
    
}

//MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension HomeHotReadingView: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: BookCollectionViewCell.toString(), for: indexPath) as! BookCollectionViewCell
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
//        self.clickBookBlock?(booksModel[indexPath.row])   数组暂时没有数据，关闭该功能
        self.clickBookBlock?(BookInfoModel(JSONString: "")) // 数据暂时没有，返回假数据
    }
    
}
