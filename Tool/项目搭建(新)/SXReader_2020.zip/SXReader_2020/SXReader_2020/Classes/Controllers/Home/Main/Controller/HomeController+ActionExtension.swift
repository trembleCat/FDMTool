//
//  HomeController+ActionExtension.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/22.
//

import UIKit

//MARK: - Action
extension HomeController {
    func createAction() {
        
        /* 点击搜索 */
        let tapSearch = UITapGestureRecognizer(target: self, action: #selector(clickPageSearchView))
        pageSearchView.addGestureRecognizer(tapSearch)
        
        /* PageManager */
        let models = getPageHeaderModels()
        
        pageManager.progressDelegate = headerAnimation
        pageManager.setHeaderModels(models)
        pageManager.setTarget(self, childControllers: childControllers)
    }
    
    /**
     获取PageManager导航模型
     */
    func getPageHeaderModels() -> [FDMPageHeaderModel] {
        var models = [FDMPageHeaderModel]()
        
        for title in pageTitles {
            
            let titleView = FDMPageZoomHeaderView()
            titleView.titleLabel.text = title
            titleView.selectLabel.text = title
            
            let model = FDMPageHeaderModel(.PageCustom, view: titleView)
            models.append(model)
        }
        
        let searchModel = FDMPageHeaderModel(.Custom, view: pageSearchView, size: .init(width: 145, height: 32))
        models.append(searchModel)
        
        return models
    }
    
    /**
     点击搜索
     */
    @objc func clickPageSearchView() {
        FLog(title: "点击搜索", message: "")
    }
}
