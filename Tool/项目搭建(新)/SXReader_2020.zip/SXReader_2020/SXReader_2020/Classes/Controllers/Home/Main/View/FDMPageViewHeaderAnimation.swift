//
//  FDMPageViewHeaderAnimation.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/23.
//

import UIKit

//MARK: - HeaderAnimation
class FDMPageViewHeaderAnimation: NSObject {
    
    var index = 0
    var headerModels: [FDMPageHeaderModel]?
    var pageCenters: [CGPoint]?
    var animationView: UIImageView?
    var animationWidth: CGFloat = 0
}

//MARK: - Action
extension FDMPageViewHeaderAnimation {
    func createAnimation(_ view: UIView) {
        guard animationView == nil else { return }
        animationView = UIImageView()
        animationView?.image = UIImage(named: "icon_PageAnimation")
        animationView?.sizeToFit()
        animationWidth = animationView?.width ?? 0
        view.addSubview(animationView!)
    }
}

//MARK: - FDMPageViewProgressDelegate
extension FDMPageViewHeaderAnimation: FDMPageViewProgressDelegate {
    func pageView(_ pageModels: [FDMPageHeaderModel]) {
        headerModels = pageModels
    }
    
    func animationProgress(_ view: UIView, pageCenters: [CGPoint]) {
        self.pageCenters = pageCenters
        createAnimation(view)
        
        animationView?.center.x = pageCenters[index].x
    }
    
    func currentSelectIndex(_ index: Int) {
        self.index = index
        
        // 文字选中
        let pageView = headerModels?[index].customView as? FDMPageZoomHeaderView
        pageView?.titleLabel.alpha = 1
        pageView?.selectLabel.alpha = 1
        pageView?.titleLabel.font = UIFont.init(name: "PingFangSC-Regular", size: 20)
        pageView?.selectLabel.font = UIFont.init(name: "PingFangSC-Medium", size: 20)
        
        // 进度条选中
        guard pageCenters?.count ?? 0 >= index else { return }
        animationView?.center.x = pageCenters?[index].x ?? -100
    }
    
    func pageViewProgress(_ completeProgress: CGFloat, smallTagIndex: Int, smallTagProgress: CGFloat, bigTagIndex: Int, bigTagProgress: CGFloat) {
        
        // 文字选中动画
        let smallPageView = headerModels?[smallTagIndex].customView as? FDMPageZoomHeaderView
        let bigPageView = headerModels?[bigTagIndex].customView as? FDMPageZoomHeaderView
        
        smallPageView?.selectLabel.alpha = smallTagProgress
        smallPageView?.titleLabel.font = UIFont.init(name: "PingFangSC-Regular", size: 16 + 4 * smallTagProgress)
        smallPageView?.selectLabel.font = UIFont.init(name: "PingFangSC-Medium", size: 16 + 4 * smallTagProgress)
        
        bigPageView?.selectLabel.alpha = bigTagProgress
        bigPageView?.titleLabel.font = UIFont.init(name: "PingFangSC-Regular", size: 16 + 4 * bigTagProgress)
        bigPageView?.selectLabel.font = UIFont.init(name: "PingFangSC-Medium", size: 16 + 4 * bigTagProgress)
        
        // 进度条选中动画
        guard pageCenters?.count ?? 0 >= bigTagIndex else { return }
        
        let smallX = pageCenters?[smallTagIndex].x ?? 0
        let bigX = pageCenters?[bigTagIndex].x ?? 0
        let centerSpacing = bigX - smallX
        
        animationView?.center.x = smallX + (centerSpacing * bigTagProgress)
        
        if bigTagProgress < 0.5 {
            animationView?.width = CGFloat(animationWidth - animationWidth * bigTagProgress)
        }else if bigTagProgress > 0.5 {
            animationView?.width = CGFloat(animationWidth - animationWidth * smallTagProgress)
        }
    }
}
