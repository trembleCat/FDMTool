//
//  CourseDetailsController+ActionExtension.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/1/11.
//

import UIKit

//MARK: - Action
extension CourseDetailsController {
    func createAction() {
        /* 关闭scrollView自动下移 */
        if #available(iOS 11.0, *) { scrollView.contentInsetAdjustmentBehavior = .never }
        if #available(iOS 13.0, *) { scrollView.automaticallyAdjustsScrollIndicatorInsets = false }
        
        backBtn.addTarget(self, action: #selector(clickBackBtn), for: .touchUpInside)
    }
    
    /**
     点击返回
     */
    @objc func clickBackBtn() {
        self.navigationController?.popViewController(animated: true)
    }
}
