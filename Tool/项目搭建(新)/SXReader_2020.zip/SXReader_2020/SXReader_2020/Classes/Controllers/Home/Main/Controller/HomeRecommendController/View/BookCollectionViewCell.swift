//
//  BookCollectionViewCell.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/25.
//

import UIKit

//MARK: - BookCollectionViewCell
class BookCollectionViewCell: UIBaseCollectionViewCell {
    
    let bookBgImgView = UIImageView()
    let bookImgView = UIImageView()
    let bookTitleLabel = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        createUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

//MARK: - UI
extension BookCollectionViewCell {
    
    func createUI() {
        self.contentView.addSubview(bookBgImgView)
        self.contentView.addSubview(bookTitleLabel)
        self.bookBgImgView.addSubview(bookImgView)
        
        /* 书籍背景阴影图 */
        bookBgImgView.image = UIImage(named: "bg_BookImage")
        bookBgImgView.snp.makeConstraints { (make) in
            make.left.top.right.equalToSuperview()
            make.bottom.equalTo(bookTitleLabel.snp.top).offset(-10)
        }
        
        /* 书籍标题 */
        bookTitleLabel.text = "书籍名称书籍名称书籍名称书籍名称"
        bookTitleLabel.numberOfLines = 2
        bookTitleLabel.setFontName("PingFangSC-Regular", fontSize: 14, fontColor: .UsedHex333333())
        bookTitleLabel.snp.makeConstraints { (make) in
            make.left.bottom.right.equalToSuperview()
            make.height.equalTo(40)
        }
        
        /* 书籍图片 */
        bookImgView.layer.cornerRadius = 4
        bookImgView.layer.masksToBounds = true
        bookImgView.image = UIImage(named: "icon_PlaceholderBook")
        bookImgView.snp.makeConstraints { (make) in
            make.right.equalToSuperview().offset(-6)
            make.left.equalToSuperview().offset(6)
            make.top.equalToSuperview().offset(5)
            make.bottom.equalToSuperview().offset(-7.5)
        }
    }
    
}
