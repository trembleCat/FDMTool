//
//  HomeCourseHeaderReusableView.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/1/5.
//

import UIKit

//MARK: - collectionHeaderView
class HomeCourseHeaderReusableView: UICollectionReusableView {
    
    let lineSpacing = UIView()
    let titleView = TitleHeaderView()
    
    var clickSubTitleBlock: (() -> ())?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        createUI()
        createAction()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

//MARK: - UI
extension HomeCourseHeaderReusableView {
    func createUI() {
        self.addSubview(lineSpacing)
        self.addSubview(titleView)
        
        /* 分割线 */
        lineSpacing.isHidden = true
        lineSpacing.backgroundColor = .UsedHexE8E8E8()
        lineSpacing.snp.makeConstraints { (make) in
            make.left.top.right.equalToSuperview()
            make.height.equalTo(0.5)
        }
        
        /* titleView */
        titleView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(15)
            make.right.equalToSuperview().offset(-20)
            make.bottom.equalToSuperview()
            make.top.equalTo(lineSpacing.snp.bottom).offset(10)
        }
    }
}

//MARK: - Action
extension HomeCourseHeaderReusableView {
    func createAction() {
        let subTitleString = NSMutableAttributedString(string: "查看全部")
        subTitleString.addFont(UIFont.init(name: "PingFangSC-Regular", size: 14)!)
        subTitleString.addForegroundColor(.UsedHex999999())
        
        titleView.setSubTitle(subTitleString, image: UIImage(named: "icon_WorksRightArrow"))
        titleView.addSubTitleTarget(self, action: #selector(clickSubTitle))
    }
    
    /**
     是否显示分割线
     */
    func showLineSpacing(_ isHidden: Bool) {
        self.lineSpacing.isHidden = !isHidden
    }
    
    /**
     设置标题
     */
    func setTitle(_ text: String) {
        let titleAttrs = NSMutableAttributedString(string: text)
        titleAttrs.addForegroundColor(.UsedHex333333())
        titleAttrs.addFont(UIFont(name: "PingFangSC-Medium", size: 16)!)
        
        titleView.setTitle(titleAttrs)
    }
    
    /**
     点击子标题
     */
    @objc func clickSubTitle() {
        self.clickSubTitleBlock?()
    }
}
