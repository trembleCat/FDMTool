//
//  HomeListenBookCell.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/1/6.
//

import UIKit

//MARK: - 首页听书列表Cell
class HomeListenBookCell: UIBaseTableViewCell {
    
    let bookView = BookInfoView(isShowAbstract: false)
    let listernImgView = UIImageView()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        createUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

//MARK: - UI
extension HomeListenBookCell {
    func createUI() {
        self.contentView.addSubview(bookView)
        self.bookView.addSubview(listernImgView)
        
        /* 书籍 */
        bookView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(5)
            make.bottom.equalToSuperview().offset(-5)
            make.left.equalToSuperview().offset(10)
            make.right.equalToSuperview().offset(-10)
        }
        
        /* 听书标识 */
        listernImgView.image = UIImage(named: "icon_ListenTag")
        listernImgView.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(25)
            make.bottom.equalToSuperview().offset(-10)
            make.width.height.equalTo(27)
        }
    }
}

//MARK: - Action
extension HomeListenBookCell {
    /**
     设置书籍模型
     */
    func setModel() {
        bookView.setBookModel(nil)
    }
}
