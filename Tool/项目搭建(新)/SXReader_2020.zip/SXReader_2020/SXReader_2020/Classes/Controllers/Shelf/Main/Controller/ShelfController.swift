//
//  ShelfController.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/11/24.
//

import UIKit

class ShelfController: UIBaseViewController {
    override var name: String {"书架"}

    override func viewDidLoad() {
        super.viewDidLoad()

    }
}
