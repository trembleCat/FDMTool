//
//  UIBaseCollectionViewCell.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/25.
//

import UIKit

class UIBaseCollectionViewCell: UICollectionViewCell {
    
}

//MARK: - Action
extension UIBaseCollectionViewCell {
    /**
     返回当前类型的String
     */
    class func toString() -> String {
        return NSStringFromClass(self)
    }
}
