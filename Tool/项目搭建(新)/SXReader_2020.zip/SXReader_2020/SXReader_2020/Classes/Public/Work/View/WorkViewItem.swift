//
//  WorkViewItem.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/24.
//

import UIKit

//MARK: - 首页优秀作品项
class WorkViewItem: UIControl {
    
    let titleLabel = UILabel()
    let subTitleLabel = UILabel()
    let schoolLabel = UILabel()
    let timeLabel = UILabel()
    let imgView = UIImageView()

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        createUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

//MARK: - UI
extension WorkViewItem {
    
    func createUI() {
        self.addSubview(titleLabel)
        self.addSubview(subTitleLabel)
        self.addSubview(schoolLabel)
        self.addSubview(timeLabel)
        self.addSubview(imgView)
        
        /* 配图 */
        imgView.backgroundColor = .orange
        imgView.layer.cornerRadius = 4
        imgView.snp.makeConstraints { (make) in
            make.right.equalToSuperview()
            make.width.equalTo(109)
            make.height.equalTo(81)
            make.top.equalToSuperview()
        }
        
        /* 标题 */
        titleLabel.text = "读骆驼祥子有感"
        titleLabel.setFontName("PingFangSC-Medium", fontSize: 18, fontColor: .UsedHex333333())
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview()
            make.top.equalTo(imgView.snp.top)
            make.right.lessThanOrEqualTo(imgView.snp.left).offset(-15)
        }
        
        /* 副标题 */
        subTitleLabel.text = "如果这个只会上演悲剧，只会否定个人奋斗道路的社会变的…"
        subTitleLabel.numberOfLines = 2
        subTitleLabel.setFontName("PingFangSC-Regular", fontSize: 13, fontColor: .UsedHex666666())
        subTitleLabel.snp.makeConstraints { (make) in
            make.top.equalTo(titleLabel.snp.bottom).offset(10)
            make.left.equalTo(titleLabel.snp.left)
            make.right.equalTo(imgView.snp.left).offset(-15)
            make.bottom.equalTo(imgView.snp.bottom)
        }
        
        /* 学校姓名 */
        schoolLabel.text = "李文豪 / 安徽巢湖春晖学校"
        schoolLabel.setFontName("PingFangSC-Light", fontSize: 12, fontColor: .UsedHex999999())
        schoolLabel.snp.makeConstraints { (make) in
            make.left.equalTo(subTitleLabel.snp.left)
            make.top.equalTo(imgView.snp.bottom).offset(10)
            make.right.lessThanOrEqualTo(timeLabel.snp.left)
        }
        
        /* 时间 */
        timeLabel.text = "2020.06.12"
        timeLabel.setFontName("PingFangSC-Light", fontSize: 12, fontColor: .UsedHex999999())
        timeLabel.snp.makeConstraints { (make) in
            make.right.equalTo(imgView.snp.right)
            make.centerY.equalTo(schoolLabel.snp.centerY)
        }
    }
    
}
