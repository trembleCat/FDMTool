//
//  ListenBookCatalogController.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/1/8.
//

import UIKit

class ListenBookCatalogController: UIBaseViewController {
    override var name: String {"听书目录"}
    
    let backDropView = UIView()
    let titleLabel = UILabel()
    let lineSpacing = UIView()
    let tableView = UITableView()
    let closeBtn = UIButton()
    
    var clickCloseBlock: (() -> ())?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .clear
        
        createUI()
    }
}

//MARK: - UI
extension ListenBookCatalogController {
    func createUI() {
        self.view.addSubview(backDropView)
        self.backDropView.addSubview(titleLabel)
        self.backDropView.addSubview(lineSpacing)
        self.backDropView.addSubview(tableView)
        self.backDropView.addSubview(closeBtn)
        
        /* 背景 */
        backDropView.layer.cornerRadius = 20
        backDropView.backgroundColor = .white
        backDropView.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.top.equalToSuperview().offset(70)
        }
        
        /* 标题 */
        titleLabel.text = "共25章"
        titleLabel.setFontName("PingFangSC-Regular", fontSize: 15, fontColor: .UsedHex333333())
        titleLabel.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(13)
            make.left.equalToSuperview().offset(20)
            make.right.lessThanOrEqualToSuperview().offset(-20)
        }
        
        /* 分割线 */
        lineSpacing.backgroundColor = .Hex("#E7E7E7")
        lineSpacing.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.top.equalTo(titleLabel.snp.bottom).offset(12.5)
            make.height.equalTo(0.5)
        }
        
        /* 关闭 */
        closeBtn.backgroundColor = .white
        closeBtn.setTitle("关闭", for: .normal)
        closeBtn.setTitleColor(.Hex("#333333"), for: .normal)
        closeBtn.titleLabel?.font = UIFont(name: "PingFangSC-Medium", size: 18)
        closeBtn.addTarget(self, action: #selector(clickCloseBtn), for: .touchUpInside)
        closeBtn.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(70)
        }
        
        /* 目录列表 */
        tableView.delegate = self
        tableView.dataSource = self
        tableView.rowHeight = 55
        tableView.separatorStyle = .none
        tableView.register(ListenBookCatalogCell.self, forCellReuseIdentifier: ListenBookCatalogCell.toString())
        tableView.snp.makeConstraints { (make) in
            make.top.equalTo(lineSpacing.snp.bottom)
            make.left.right.equalToSuperview()
            make.bottom.equalTo(closeBtn.snp.top)
        }
    }
}


