//
//  ListenBookDetailsController+ActionDelegate.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/1/8.
//

import UIKit

//MARK: - FDMAudioPlayerControlDelegate
extension ListenBookDetailsController: FDMAudioPlayerControlDelegate {
    func audioPlayerControl(_ audioControl: FDMAudioPlayerControl, clickPlayer sender: UIButton) {
        
    }
    
    func audioPlayerControl(_ audioControl: FDMAudioPlayerControl, clickLast sender: UIButton) {
        
    }
    
    func audioPlayerControl(_ audioControl: FDMAudioPlayerControl, clickNext sender: UIButton) {
        
    }
    
    func audioPlayerControl(_ audioControl: FDMAudioPlayerControl, clickCollection sender: UIButton) {
        
    }
    
    func audioPlayerControl(_ audioControl: FDMAudioPlayerControl, clickCatalog sender: UIButton) {
        
        UIView.animate(withDuration: 0.3) { [weak self] in
            self?.shadowView?.alpha = 1
        }
        
        let vc = ListenBookCatalogController()
        vc.modalPresentationStyle = .overFullScreen
        vc.clickCloseBlock = { [weak self] in
            self?.shadowView?.alpha = 0
        }
        
        self.present(vc, animated: true, completion: nil)
    }
    
    func audioProgressView(_ progressView: FDMProgressView, didDraggingProgressView currentValue: CGFloat) {
        
    }
}
