//
//  ListenBookCatalogController+ActionExtension.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/1/8.
//

import UIKit


//MARK: - Action
extension ListenBookCatalogController {
    
    /**
     点击关闭
     */
    @objc func clickCloseBtn() {
        self.clickCloseBlock?()
        self.dismiss(animated: true, completion: nil)
    }
}

//MARK: - UITableViewDelegate, UITableViewDataSource
extension ListenBookCatalogController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 10
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: ListenBookCatalogCell.toString(), for: indexPath) as! ListenBookCatalogCell
        cell.selectionStyle = .none
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // 修改数据, 刷新indexpath的cell
        
    }
}
