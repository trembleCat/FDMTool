//
//  ListenBookDetailsController.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/1/7.
//

import UIKit

class ListenBookDetailsController: UIBaseViewController {
    override var name: String {"听书播放页面"}
    
    let audioView = FDMAudioPlayerView()
    let backBtn = UIButton()
    
    var shadowView: UIView? = {
        let content = UIView()
        content.backgroundColor = .Hex("#000000", alpha: 0.5)
        content.alpha = 0
        content.frame = CGRect(origin: .zero, size: .init(width: FScreenW, height: FScreenH))
        
        return content
    }()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        createUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.setNavigationBarHidden(true)
    }
}

//MARK: - UI
extension ListenBookDetailsController {
    func createUI() {
        self.view.addSubview(audioView)
        self.view.addSubview(backBtn)
        self.view.addSubview(shadowView!)
        
        /* 音频播放页面 */
        audioView.delegate = self
        audioView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        /* 退出按钮 */
        backBtn.setImage(UIImage(named: "icon_Back"), for: .normal)
        backBtn.addTarget(self, action: #selector(clickCloseBtn), for: .touchUpInside)
        backBtn.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(15)
            make.top.equalToSuperview().offset(20 + FDMTool.statusHeight())
            make.width.height.equalTo(30)
        }
    }
}


//MARK: - Action
extension ListenBookDetailsController {
    
    /**
     点击退出
     */
    @objc func clickCloseBtn() {
        self.navigationController?.popViewController(animated: true)
    }
}
