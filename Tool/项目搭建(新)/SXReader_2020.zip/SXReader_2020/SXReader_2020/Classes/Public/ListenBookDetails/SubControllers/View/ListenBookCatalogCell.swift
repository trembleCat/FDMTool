//
//  ListenBookCatalogCell.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/1/8.
//

import UIKit

//MARK: - 听书目录Cell
class ListenBookCatalogCell: UIBaseTableViewCell {
    
    let titleimgView = UIImageView()
    let titleLabel = UILabel()
    let spacingLine = UIView()

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        createUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

//MARK: - UI
extension ListenBookCatalogCell {
    func createUI() {
        self.contentView.addSubview(titleimgView)
        self.contentView.addSubview(titleLabel)
        self.contentView.addSubview(spacingLine)
        
        /* 图片 */
        titleimgView.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.left.equalToSuperview().offset(17)
            make.width.equalTo(0)
            make.height.equalTo(10)
        }
        
        /* 标题 */
        titleLabel.text = "第一章     命运晚餐"
        titleLabel.setFontName("PingFangSC-Regular", fontSize: 13, fontColor: .UsedHex333333())
        titleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(titleimgView.snp.right).offset(5)
            make.centerY.equalToSuperview()
            make.right.equalToSuperview().offset(-5)
        }
        
        /* 分割线 */
        spacingLine.backgroundColor = .UsedHexE8E8E8()
        spacingLine.snp.makeConstraints { (make) in
            make.right.equalToSuperview()
            make.bottom.equalToSuperview()
            make.height.equalTo(0.5)
            make.left.equalToSuperview().offset(17)
        }
    }
    
    /**
     是否为播放中
     */
    func showPlaying(_ isPlaying: Bool) {
        
        titleimgView.image = isPlaying ? UIImage(named: "audioPlayer_Headset") : nil
        titleimgView.snp.updateConstraints { (make) in
            make.width.equalTo(isPlaying ? 20 : 0)
        }
        
    }
}
