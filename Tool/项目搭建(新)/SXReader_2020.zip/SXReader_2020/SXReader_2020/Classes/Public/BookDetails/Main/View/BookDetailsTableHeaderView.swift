//
//  BookDetailsTableHeaderView.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/2/22.
//

import UIKit

//MARK: - 书籍详情介绍
class BookDetailsTableHeaderView: UIView {
    
    let bookInfoBackDropView = UIView()
    let bookImgBgView = UIImageView()
    let bookImgView = UIImageView()
    
    let bookTitleLabel = UILabel()
    let bookAuthorLabel = UILabel()
    let bookPressLabel = UILabel()
    let bookPricesLabel = UILabel()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.backgroundColor = .mainColor()
        createUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

//MARK: - UI
extension BookDetailsTableHeaderView {
    func createUI() {
        self.addSubview(bookInfoBackDropView)
        self.bookInfoBackDropView.addSubview(bookImgBgView)
        self.bookImgBgView.addSubview(bookImgView)
        self.bookInfoBackDropView.addSubview(bookTitleLabel)
        self.bookInfoBackDropView.addSubview(bookAuthorLabel)
        self.bookInfoBackDropView.addSubview(bookPressLabel)
        self.bookInfoBackDropView.addSubview(bookPricesLabel)
        
        /* 信息背景 */
        bookInfoBackDropView.backgroundColor = .mainColor()
        bookInfoBackDropView.snp.makeConstraints { (make) in
            make.top.left.right.equalToSuperview()
            make.height.equalTo(160)
        }
        
        /* 书籍图片背景 */
        bookImgBgView.image = UIImage.init(named: "bg_BookImage")
        bookImgBgView.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.left.equalToSuperview().offset(15)
            make.width.equalTo(100)
            make.height.equalTo(134)
        }
        
        /* 书籍图片 */
        bookImgView.layer.cornerRadius = 5
        bookImgView.layer.masksToBounds = true
        bookImgView.image = UIImage(named: "icon_PlaceholderBook")
        bookImgView.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(5)
            make.left.equalToSuperview().offset(7)
            make.right.equalToSuperview().offset(-7)
            make.bottom.equalToSuperview().offset(-9)
        }
        
        /* 书名 */
        bookTitleLabel.text = "假如给我三天光明"
        bookTitleLabel.numberOfLines = 0
        bookTitleLabel.setFontName("PingFangSC-Medium", fontSize: 15, fontColor: .UsedHex333333())
        bookTitleLabel.snp.makeConstraints { (make) in
            make.left.equalTo(bookImgBgView.snp.right).offset(15)
            make.top.equalTo(bookImgView.snp.top)
            make.right.lessThanOrEqualToSuperview().offset(-15)
        }
        
        /* 作者 */
        bookAuthorLabel.text = "[美] 海伦·凯勒"
        bookAuthorLabel.numberOfLines = 0
        bookAuthorLabel.setFontName("PingFangSC-Regular", fontSize: 12, fontColor: .UsedHex666666())
        bookAuthorLabel.snp.makeConstraints { (make) in
            make.left.equalTo(bookTitleLabel.snp.left)
            make.top.equalTo(bookTitleLabel.snp.bottom).offset(12)
            make.right.lessThanOrEqualToSuperview().offset(-15)
        }
        
        /* 出版社 */
        bookPressLabel.text = "上海译文出版社"
        bookPressLabel.numberOfLines = 0
        bookPressLabel.setFontName("PingFangSC-Regular", fontSize: 12, fontColor: .UsedHex666666())
        bookPressLabel.snp.makeConstraints { (make) in
            make.left.equalTo(bookTitleLabel.snp.left)
            make.top.equalTo(bookAuthorLabel.snp.bottom).offset(12)
            make.right.lessThanOrEqualToSuperview().offset(-15)
        }
        
        /* 价格 */
        bookPricesLabel.text = "纸质书价 ¥19.99    电子书价 ¥9.99"
        bookPricesLabel.setFontName("PingFangSC-Regular", fontSize: 12, fontColor: .UsedHex666666())
        bookPricesLabel.snp.makeConstraints { (make) in
            make.left.equalTo(bookTitleLabel.snp.left)
            make.top.equalTo(bookPressLabel.snp.bottom).offset(12)
            make.right.lessThanOrEqualToSuperview().offset(-15)
        }
    }
}
