//
//  BookDetailsSectionHeaderView.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/2/22.
//

import UIKit

//MARK: - 书籍详情书评标题
class BookDetailsSectionHeaderView: UIView {

}
