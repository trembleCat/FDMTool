//
//  BookDetailsController.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/2/22.
//

import UIKit

class BookDetailsController: UIBaseViewController {
    override var name: String {"书籍详情"}
    
    let tableView = UITableView()
    let headerView = BookDetailsTableHeaderView()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        createUI()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        setNavigationBarHidden(false, animated: true)
    }
}

//MARK: - UI
extension BookDetailsController {
    func createUI() {
        self.view.addSubview(tableView)
        
        /* tableView */
        tableView.delegate = self
        tableView.dataSource = self
        tableView.rowHeight = 44
        tableView.register(BookDetailsCommentCell.self, forCellReuseIdentifier: BookDetailsCommentCell.toString())
        tableView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        /* headerView */
        tableView.tableHeaderView = headerView
        headerView.snp.makeConstraints { (make) in
            make.width.equalTo(FScreenW)
            make.height.equalTo(160)
        }
        headerView.layoutIfNeeded()
    }
}
