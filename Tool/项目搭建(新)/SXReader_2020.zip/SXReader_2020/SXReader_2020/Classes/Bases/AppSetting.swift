//
//  AppSetting.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/11/26.
//

import UIKit

//MARK: - 项目类型
enum TargetType {
    case Student
    case Teacher
}

class AppSetting: NSObject {
    static let shared = AppSetting()
    
}

//MARK: - Image
extension UIImageView {
    /**
     模拟设置网络图片
     */
    func setImage_simulation() {
        
    }
}
