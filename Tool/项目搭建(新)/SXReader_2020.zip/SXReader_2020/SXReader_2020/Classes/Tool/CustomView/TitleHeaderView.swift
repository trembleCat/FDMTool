//
//  TitleHeaderView.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/24.
//

import UIKit

//MARK: - 标题栏，副标题可点击
class TitleHeaderView: UIView {
    
    let titleLabel = UILabel()
    let subTitleBtn = FDMCustomButton()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        createUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}


//MARK: - UI
extension TitleHeaderView {
    
    private func createUI() {
        self.addSubview(titleLabel)
        self.addSubview(subTitleBtn)
        
        /* 标题 */
        titleLabel.snp.makeConstraints { (make) in
            make.top.bottom.equalToSuperview()
            make.left.equalToSuperview()
        }
        
        /* 副标题 */
        subTitleBtn.imagePosition = .FDMButtomImageRight
        subTitleBtn.imageSpacing = 5
        subTitleBtn.snp.makeConstraints { (make) in
            make.right.equalToSuperview()
            make.centerY.equalTo(titleLabel.snp.centerY)
        }
    }
    
}

//MARK: - Action
extension TitleHeaderView {
    
    /**
     设置标题
     */
    func setTitle(_ title: NSAttributedString) {
        titleLabel.attributedText = title
    }
    
    /**
     设置副标题及图片
     */
    func setSubTitle(_ title: NSAttributedString, image: UIImage?) {
        subTitleBtn.setAttributedTitle(title, for: .normal)
        subTitleBtn.setImage(image, for: .normal)
    }
    
    /**
     设置副标题点击事件
     */
    func addSubTitleTarget(_ target: Any?, action select: Selector) {
        self.subTitleBtn.addTarget(target, action: select, for: .touchUpInside)
    }
    
}
