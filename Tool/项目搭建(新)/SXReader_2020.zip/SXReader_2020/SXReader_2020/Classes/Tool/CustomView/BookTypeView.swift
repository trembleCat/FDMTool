//
//  BookTypeView.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/1/6.
//

import UIKit

//MARK: - BookTypeViewDelegate
protocol BookTypeViewDelegate: NSObjectProtocol {
    /// 选项被选中回调
    func selectedTypeBtn(_ isShow: Bool, index: Int)
}

//MARK: - 书籍类型选择
class BookTypeView: UIView {
    
    let bookTypeBtn = FDMCustomButton()
    let gradeTypeBtn = FDMCustomButton()
    let subjectTypeBtn = FDMCustomButton()
    
    let lineSpacing = UIView()
    var selectedTypeBtn: FDMCustomButton?
    
    weak var delegate: BookTypeViewDelegate?

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        createUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

//MARK: - UI
extension BookTypeView {
    private func createUI() {
        self.addSubview(lineSpacing)
        
        /* stackView */
        let stackView = UIStackView(arrangedSubviews: [bookTypeBtn, gradeTypeBtn, subjectTypeBtn])
        stackView.alignment = .fill
        stackView.axis = .horizontal
        stackView.distribution = .fillEqually
        
        self.addSubview(stackView)
        stackView.snp.makeConstraints { (make) in
            make.left.top.right.equalToSuperview()
            make.bottom.equalTo(lineSpacing.snp.top)
        }
        
        /* 全部分类 */
        bookTypeBtn.tag = 0
        bookTypeBtn.setTitle("全部分类 ", for: .normal)
        setCustomButtonProporty(bookTypeBtn)
        
        /* 全部学段 */
        gradeTypeBtn.tag = 1
        gradeTypeBtn.setTitle("全部学段 ", for: .normal)
        setCustomButtonProporty(gradeTypeBtn)
        
        /* 全部学科 */
        subjectTypeBtn.tag = 2
        subjectTypeBtn.setTitle("全部学科 ", for: .normal)
        setCustomButtonProporty(subjectTypeBtn)
        
        /* 分割线 */
        lineSpacing.backgroundColor = .Hex("#E7E7E7")
        lineSpacing.snp.makeConstraints { (make) in
            make.left.right.bottom.equalToSuperview()
            make.height.equalTo(0.5)
        }
    }
}

//MARK: - Action
extension BookTypeView {
    
    /**
     设置按钮属性
     */
    private func setCustomButtonProporty(_ sender: FDMCustomButton) {
        sender.imagePosition = .FDMButtomImageRight
        sender.setTitleColor(.UsedHex666666(), for: .normal)
        sender.setTitleColor(.Hex("#8B572A"), for: .selected)
        sender.setImage(UIImage(named: "icon_SelectedNormal"), for: .normal)
        sender.setImage(UIImage(named: "icon_SelectedUp"), for: .selected)
        sender.titleLabel?.font = UIFont(name: "PingFangSC-Regular", size: 14)
        sender.addTarget(self, action: #selector(clickTypeBtn(_:)), for: .touchUpInside)
    }
    
    /**
     点击按钮
     */
    @objc private func clickTypeBtn(_ sender: FDMCustomButton) {
        bookTypeBtn.isSelected = bookTypeBtn == sender ? !sender.isSelected : false
        gradeTypeBtn.isSelected = gradeTypeBtn == sender ? !sender.isSelected : false
        subjectTypeBtn.isSelected = subjectTypeBtn == sender ? !sender.isSelected : false
        
        if sender.isSelected {
            sender.titleLabel?.font = UIFont(name: "PingFangSC-Medium", size: 14)
        }else {
            sender.titleLabel?.font = UIFont(name: "PingFangSC-Regular", size: 14)
        }
        
        selectedTypeBtn = sender
        delegate?.selectedTypeBtn(sender.isSelected, index: sender.tag)
    }
    
    /**
     设置标题
     */
    func setTitleName(_ name: String) {
        selectedTypeBtn?.setTitle(name, for: .normal)
    }
}
