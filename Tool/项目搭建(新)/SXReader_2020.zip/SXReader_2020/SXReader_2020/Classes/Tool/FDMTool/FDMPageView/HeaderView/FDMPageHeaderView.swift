//
//  FDMPageHeaderView.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/21.
//

import UIKit

//MARK: - FDMPageHeaderViewDelegate
protocol FDMPageHeaderViewDelegate: NSObjectProtocol {
    func clickTitleView(_ view: UIControl, index: Int, type: FDMPageHeaderModel.HeaderViewType)
    
    /**
     返回所有为Page的Model
     */
    func pageView(_ pageModels: [FDMPageHeaderModel])
}


//MARK: - HeaderView(标题不能滚动)
class FDMPageHeaderView: UIView {
    
    weak var delegate: FDMPageHeaderViewDelegate?
    var titleHeight: CGFloat = 40
    var animationHeight: CGFloat = 20 
    
    let scrollView = UIScrollView()
    let contentTitleView = UIView()
    let contentAnimationView = UIView()
    
    // 以下属性直接修改无效，请通过提供的方法进行设置
    var index = 0
    var knownWidthCount: CGFloat = 0    // 拥有固定宽度的view个数
    var KnownWidth: CGFloat = 0         // 拥有固定宽度的View的总宽度
    var unKnownWidthCount: CGFloat = 0  // 未知宽度的view个数
    
    var pageHeaderModels = [FDMPageHeaderModel]()   // 所有的model
    var selectTitleModels = [FDMPageHeaderModel]()  // 不属于page的Title
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        createUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

//MARK: - UI
extension FDMPageHeaderView {
    func createUI() {
        self.addSubview(scrollView)
        self.scrollView.addSubview(contentTitleView)
        self.scrollView.addSubview(contentAnimationView)
        
    }
}

//MARK: - Layout
extension FDMPageHeaderView {
    override func layoutSubviews() {
        super.layoutSubviews()
        
        scrollView.frame = self.bounds
        contentTitleView.frame = CGRect(x: 0, y: 0, width: self.bounds.width, height: titleHeight)
        contentAnimationView.frame = CGRect(x: 0, y: titleHeight, width: self.bounds.width, height: animationHeight)
        
        layoutAllTitleView((contentTitleView.bounds.width - KnownWidth) / unKnownWidthCount)
    }
    
    /**
     布局所有TitleView
     */
    func layoutAllTitleView(_ unKnownWidth: CGFloat) {
        
        var i = 0
        for model in pageHeaderModels {
            
            let x = i == 0 ? 0 : pageHeaderModels[i - 1].customView.frame.origin.x + pageHeaderModels[i - 1].customView.frame.size.width
            
            let width  = model.customSize == .zero ? unKnownWidth : model.customSize.width
            
            model.customView.frame = .init(x: x, y: 0, width: width, height: titleHeight)
            
            i += 1
        }
    }
    
}
