//
//  FDMTipsBackDrop.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/2/22.
//

import UIKit

class FDMTipsBackDrop: UIView {
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.4)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
