//
//  FDMPageView.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/21.
//

import UIKit

protocol FDMPageViewProgressDelegate: NSObjectProtocol {
    /**
     返回所有为Page的Model
     */
    func pageView(_ pageModels: [FDMPageHeaderModel])
    
    /**
     当前选中Index
     */
    func currentSelectIndex(_ index: Int)
    
    /**
     返回动画View 与 page的center
     */
    func animationProgress(_ view: UIView, pageCenters: [CGPoint])
    
    /**
     页面改变进度回调
     
     - parameter completeProgress:  总体进度 范围 0 - (headerModels.count - 1)
     - parameter smallTagIndex:     标识小的 Header Index
     - parameter smallTagProgress:  标识小的 Header Progress
     - parameter bigTagIndex:       标识大的 Header Index
     - parameter bigTagProgress:    标识大的 Header Progress
     */
    func pageViewProgress(_ completeProgress: CGFloat,
                          smallTagIndex: Int,
                          smallTagProgress: CGFloat,
                          bigTagIndex: Int,
                          bigTagProgress: CGFloat)
    
}


//MARK: - PageView
class FDMPageView: UIView {
    
    let pageHeaderView = FDMPageHeaderView()
    let pageContentView = FDMPageContentView()
    
    weak var delegate: FDMPageViewProgressDelegate? { didSet { setProgressDelegate() } }
    
    var index = 0
    var smallIndex: Int = 0
    var bigIndex: Int = 0
    
    var titleHeight: CGFloat = 40 { didSet { updateHeaderViewHeight() } }
    var animationHeight: CGFloat = 20 { didSet { updateHeaderViewHeight() } }
    
    weak var target: UIViewController?
    var childControllers = [UIViewController]()
    
    /**
     初始化
     
     - parameter target: 主控制器(用于添加子控制器)
     - parameter childControllers: 子控制器
     */
    convenience init(target: UIViewController, childControllers: [UIViewController]) {
        self.init()
        
        self.target = target
        self.childControllers = childControllers
        
        readdChildControllers()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        createUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

//MARK: - UI
extension FDMPageView {
    func createUI() {
        self.addSubview(pageHeaderView)
        self.addSubview(pageContentView)
        
        /* HeaderView */
        pageHeaderView.delegate = self
        pageHeaderView.snp.makeConstraints { (make) in
            make.left.top.right.equalToSuperview()
            make.height.equalTo(titleHeight + animationHeight)
        }
        
        /* ContentView */
        pageContentView.delegate = self
        pageContentView.snp.makeConstraints { (make) in
            make.top.equalTo(pageHeaderView.snp.bottom)
            make.left.right.bottom.equalToSuperview()
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        var centes = [CGPoint]()
        for item in self.pageHeaderView.selectTitleModels {
            centes.append(item.customView.center)
        }
        
        self.delegate?.animationProgress(pageHeaderView.contentAnimationView, pageCenters: centes)
    }
}
