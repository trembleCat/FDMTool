//
//  FDMPageContentView.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/21.
//

import UIKit

//MARK: - FDMScrollContentViewDelegate
protocol FDMPageContentViewDelegate: NSObjectProtocol {
    func scrollViewDidScrollProgress(_ progress: CGFloat)
    
    func scrollViewDidEndIndex(_ index: Int)
}


//MARK: - 滚动内容View
class FDMPageContentView: UIView {
    
    weak var delegate: FDMPageContentViewDelegate?
    
    // 以下属性直接修改无效，请通过提供的方法进行设置
    let scrollView = UIScrollView()
    let contentView = UIView()
    
    var index = 0
    var childViews = [UIView]()
    var childOffset = [CGPoint]()
    var childCount: Int { childViews.count }

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        createUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

//MARK: - UI
extension FDMPageContentView {
    private func createUI() {
        self.addSubview(scrollView)
        self.scrollView.addSubview(contentView)
        
        /* 滚动View */
        scrollView.delegate = self
        scrollView.bounces = false
        scrollView.isPagingEnabled = true
        scrollView.backgroundColor = .clear
        scrollView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
}

//MARK: - Layout
extension FDMPageContentView{
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        layoutChildViews()
    }
    
    /**
     布局childViews
     */
    private func layoutChildViews() {
        guard bounds.size.width > 0 && bounds.size.height > 0 else { return }
        
        let contentSize = CGSize(width: bounds.width * CGFloat(childViews.count), height: bounds.height)
        contentView.frame = CGRect(origin: .zero, size: contentSize)
        scrollView.contentSize = contentSize
        childOffset.removeAll()
        
        var i = 0
        for childView in childViews {
            
            let origin = CGPoint(x: CGFloat(i) * bounds.width, y: 0)
            let size = bounds.size
            
            childView.tag = i
            childView.frame = .init(origin: origin, size: size)
            childOffset.append(origin)
            i += 1
        }
    }
}
