//
//  FDMPageHeaderModel.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/22.
//

import UIKit

//MARK: - HeaderModel
class FDMPageHeaderModel: NSObject {
    
    var type: HeaderViewType
    var customView: UIControl
    var customSize: CGSize = .zero
    
    var title: String?
    var normalColor: UIColor?
    var normalFont: UIFont?
    
    
    /**
     初始化Title类型
     
     - parameter title: 文字
     - parameter titleColor: 文字颜色
     - parameter titleFont: 文字大小
     */
    init(title: String, normalColor: UIColor = .black, normalFont: UIFont = .systemFont(ofSize: 16)) {
        self.type = .Title
        self.title = title
        
        let btn = UIButton()
        btn.setTitle(title, for: .normal)
        btn.setTitleColor(normalColor, for: .normal)
        btn.titleLabel?.font = normalFont
        btn.titleLabel?.textAlignment = .center
        
        customView = btn
    }
    
    /**
     初始化Custom类型
     
     - parameter type: 类型
     - parameter view: 自定义View(继承自UIControl)
     - parameter size: 大小
     */
    init(_ type: HeaderViewType, view: UIControl, size: CGSize = .zero) {
        self.type = type
        self.customView = view
        self.customSize = size
    }
}

extension FDMPageHeaderModel {
    
    /// Header类型
    enum HeaderViewType {
        case Title      // 默认标题类型
        case Custom     // 自定义View类型(不属于分页选项)
        case PageCustom // 自定义View类型(属于分页选项)
    }
}
