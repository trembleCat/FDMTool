//
//  FDMPageView+DelegateExtension.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/22.
//

import UIKit

//MARK: - ContentViewDelegate
extension FDMPageView: FDMPageContentViewDelegate {
    
    func scrollViewDidEndIndex(_ index: Int) {
        self.index = index
        self.pageHeaderView.setIndex(index)
        self.delegate?.currentSelectIndex(index)
    }
    
    func scrollViewDidScrollProgress(_ progress: CGFloat) {
        
        var smallTagIndex = (floor(progress))
        var bigTagIndex = ceil(progress)
        
        var bigTagProgress = (progress - smallTagIndex)
        var smallTagProgress = 1 - bigTagProgress
        
        if Int(smallTagIndex) == Int(bigTagIndex) {
            if Int(smallTagIndex) == smallIndex {
                smallTagProgress = 1
                bigTagProgress = 0
                
            }else {
                smallTagProgress = 0
                bigTagProgress = 1
                
            }
            
            smallTagIndex = CGFloat(smallIndex)
            bigTagIndex = CGFloat(bigIndex)
            
        }else {
            smallIndex = Int(smallTagIndex)
            bigIndex = Int(bigTagIndex)
        }
        
        self.delegate?.pageViewProgress(progress,
                                        smallTagIndex: Int(smallTagIndex),
                                        smallTagProgress: smallTagProgress,
                                        bigTagIndex: Int(bigTagIndex),
                                        bigTagProgress: bigTagProgress)
    }
}

//MARK: - HeaderViewDelegate
extension FDMPageView: FDMPageHeaderViewDelegate {
    func pageView(_ pageModels: [FDMPageHeaderModel]) {
        delegate?.pageView(pageModels)
        delegate?.currentSelectIndex(index)
    }
    
    func clickTitleView(_ view: UIControl, index: Int, type: FDMPageHeaderModel.HeaderViewType) {
        pageContentView.setIndex(at: index, animation: true)
    }
    
}
