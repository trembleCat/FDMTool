//
//  FDMAudioPlayerView.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/1/7.
//

import UIKit

//MARK: - 音频播放页面
class FDMAudioPlayerView: UIView {
    
    weak var delegate: FDMAudioPlayerControlDelegate? {
        set { playerControl.delegate = newValue }
        get { playerControl.delegate }
    }
    
    let backdropView = UIView()
    let bookImgView = UIImageView()
    
    let titleLabel = UILabel()
    let subTitleLabel = UILabel()
    
    let playerControl = FDMAudioPlayerControl()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .Hex("#F7F7F7")
        
        createUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

//MARK: - UI
extension FDMAudioPlayerView {
    func createUI() {
        self.addSubview(backdropView)
        self.backdropView.addSubview(bookImgView)
        self.addSubview(titleLabel)
        self.addSubview(subTitleLabel)
        self.addSubview(playerControl)
        
        /* 白色书籍背景 */
        backdropView.backgroundColor = .white
        backdropView.layer.cornerRadius = 6
        backdropView.layer.shadowColor = .Hex("#000000", alpha: 0.9)
        backdropView.layer.shadowRadius = 5
        backdropView.layer.shadowOpacity = 0.2
        backdropView.layer.shadowOffset = .init(width: 0, height: 0)
        backdropView.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalToSuperview().offset(FDMTool.statusHeight() + FDMTool.statusHeight() * 3)
            make.width.equalTo(126)
            make.height.equalTo(177)
        }
        
        /* 书籍图片 */
        bookImgView.image = UIImage(named: "icon_PlaceholderBook")
        bookImgView.layer.cornerRadius = 3
        bookImgView.layer.masksToBounds = true
        bookImgView.snp.makeConstraints { (make) in
            make.left.top.equalToSuperview().offset(5)
            make.bottom.right.equalToSuperview().offset(-5)
        }
        
        /* 标题 */
        titleLabel.text = "加入给我三天光明"
        titleLabel.textAlignment = .center
        titleLabel.setFontName("PingFangSC-Medium", fontSize: 20, fontColor: .UsedHex333333())
        titleLabel.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(backdropView.snp.bottom).offset(40)
            make.left.lessThanOrEqualToSuperview().offset(40)
            make.right.lessThanOrEqualToSuperview().offset(-40)
        }
        
        /* 副标题 */
        subTitleLabel.text = "第二章 蜻蜓王子和小绵羊的故事"
        subTitleLabel.textAlignment = .center
        subTitleLabel.setFontName("PingFangSC-Regular", fontSize: 15, fontColor: .UsedHex333333())
        subTitleLabel.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(titleLabel.snp.bottom).offset(25)
            make.left.lessThanOrEqualToSuperview().offset(20)
            make.right.lessThanOrEqualToSuperview().offset(-20)
        }
        
        /* 音频控制 */
        playerControl.snp.makeConstraints { (make) in
            make.left.right.equalToSuperview()
            make.bottom.equalToSuperview().offset(-FDMTool.bottomSafeHeight() - FDMTool.statusHeight())
            make.height.equalTo(120)
        }
    }
}
