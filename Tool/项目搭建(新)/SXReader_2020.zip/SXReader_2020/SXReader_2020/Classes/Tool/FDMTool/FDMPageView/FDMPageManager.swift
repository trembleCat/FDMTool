//
//  FDMPageManager.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/22.
//

import UIKit

protocol FDMPageManagerDelegate: NSObjectProtocol {
    
    /// 自定义TitleView处于选中状态
    func customTitleViewDidSelected(_ index: Int)
}


//MARK: - FDMPageManager
class FDMPageManager: NSObject {
    let contentView = FDMPageView()
    
    weak var delegate: FDMPageManagerDelegate?
    weak var progressDelegate: FDMPageViewProgressDelegate? { didSet { contentView.delegate = progressDelegate } }
    
    /// pageIndex
    var pageIndex: Int { set {setPageIndex(newValue, animation: true)} get { contentView.index } }
    
    /// 导航数组模型
    var headerModels = [FDMPageHeaderModel]() { didSet { contentView.resetHeaderModels(headerModels) } }
    
    /// 导航标题高度 default = 40
    var titleHeight: CGFloat { set { contentView.titleHeight = newValue } get { contentView.titleHeight } }
    
    /// 导航动画高度 default = 20
    var animationHeight: CGFloat { set { contentView.animationHeight = newValue } get { contentView.animationHeight } }
    
    /**
     初始化
     
     - parameter target: 主控制器(用于添加子控制器)
     - parameter childControllers: 子控制器
     */
    convenience init(target: UIViewController, childControllers: [UIViewController]) {
        self.init()
        
        contentView.resetTarget(target, childControllers: childControllers)
    }
}


//MARK: - Action
extension FDMPageManager {
    
    /**
     设置控制器与子控制器
     
     - parameter target: 主控制器(用于添加子控制器)
     - parameter childControllers: 子控制器
     */
    func setTarget(_ target: UIViewController, childControllers: [UIViewController]) {
        contentView.resetTarget(target, childControllers: childControllers)
    }
    
    /**
     设置导航模型
     
     - parameter models: 导航模型数组
     */
    func setHeaderModels(_ models: [FDMPageHeaderModel]) {
        headerModels = models
    }
    
    /**
     设置Index
     
     - parameter index: 选中页面
     - parameter animation: 是否执行动画
     */
    func setPageIndex(_ index: Int, animation: Bool) {
        contentView.setPageIndex(index, animation: animation)
    }
}

