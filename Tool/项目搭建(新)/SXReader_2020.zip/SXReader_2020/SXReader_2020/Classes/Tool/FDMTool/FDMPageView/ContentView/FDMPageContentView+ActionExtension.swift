//
//  FDMPageContentView+ActionExtension.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/21.
//

import UIKit

//MARK: - Action
extension FDMPageContentView {
    
    /**
     重置ChildViews
     */
    func resetChildViews(_ views: [UIView]) {
        contentView.removeAllSubviews()
        childViews = views
        
        for view in views {
            self.contentView.addSubview(view)
        }
        
        self.layoutSubviews()
    }
    
    /**
     添加ChildView
     */
    func addChildView(_ view: UIView) {
        childViews.append(view)
        self.contentView.addSubview(view)
        
        self.layoutSubviews()
    }
    
    /**
     插入ChildView
     */
    func insertChildView(_ view: UIView, at i: Int) {
        guard i <= childCount && childCount >= 0 else {
            FDMLog(title: "插入 ChildView 失败", message: "数组越界")
            return
        }
        
        childViews.insert(view, at: i)
        
        self.contentView.addSubview(view)
        self.layoutSubviews()
    }
    
    /**
     删除ChildView
     */
    func removeChildView(at i: Int) {
        guard i <= (childCount - 1) && childCount > 0 else {
            FDMLog(title: "删除 ChildView 失败", message: "数组越界")
            return
        }
        
        childViews[i].removeFromSuperview()
        childViews.remove(at: i)
        
        self.layoutSubviews()
    }
    
    /**
     删除所有ChildView
     */
    func removeAllChildViews() {
        contentView.removeAllSubviews()
        childViews.removeAll()
        
        self.layoutSubviews()
    }
    
    /**
     设置Index
     */
    func setIndex(at i: Int, animation: Bool) {
        guard i <= (childCount - 1) && childCount > 0 else {
            FDMLog(title: "设置 index 失败", message: "数组越界")
            return
        }
        
        index = i
        scrollView.setContentOffset(childOffset[i], animated: animation)
    }
}

//MARK: - UIScrollViewDelegate
extension FDMPageContentView: UIScrollViewDelegate {
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        self.delegate?.scrollViewDidScrollProgress(scrollView.contentOffset.x / self.bounds.width)
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        index = Int(scrollView.contentOffset.x / self.bounds.width)
        self.delegate?.scrollViewDidEndIndex(index)
    }
    
    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        index = Int(scrollView.contentOffset.x / self.bounds.width)
        self.delegate?.scrollViewDidEndIndex(index)
    }
    
    
}
