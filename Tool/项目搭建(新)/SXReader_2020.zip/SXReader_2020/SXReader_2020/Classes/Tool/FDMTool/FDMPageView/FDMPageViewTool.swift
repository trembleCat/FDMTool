//
//  FDMPageViewTool.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/21.
//

import UIKit

public func FDMLog<T,K>(title: T, message: K, file: String = #file, funcName: String = #function, lineNum: Int = #line) {
    #if DEBUG
    let fileName = (file as NSString).lastPathComponent
    print("================================\n  标题:【\(title)】\n  文件名:【\(fileName)】\n  方法名:【\(funcName)】\n  行号: 【\(lineNum)】\n  信息: 【\(message)】\n================================")
    #endif
}
