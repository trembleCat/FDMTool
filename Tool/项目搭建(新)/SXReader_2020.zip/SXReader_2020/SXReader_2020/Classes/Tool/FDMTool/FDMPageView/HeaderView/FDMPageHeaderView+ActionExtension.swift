//
//  FDMPageHeaderView+ActionExtension.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/22.
//

import UIKit

//MARK: - Action
extension FDMPageHeaderView {
    
    /**
     点击PageTitle
     */
    @objc func clickPageTitleView(_ sender: UIButton) {
        self.delegate?.clickTitleView(sender, index: sender.tag, type: selectTitleModels[sender.tag].type)
    }
    
    /**
     设置Index
     */
    func setIndex(_ i: Int) {
        guard i <= (selectTitleModels.count - 1) && selectTitleModels.count > 0 else {
            FDMLog(title: "设置 index 失败", message: "数组越界")
            return
        }
        
        index = i
    }
    
    /**
     更新高度
     */
    func updateViewLayout() {
        self.layoutIfNeeded()
        self.setNeedsLayout()
    }
    
    /**
     删除所有标题View
     */
    func removeAllTitleViews() {
        for model in pageHeaderModels {
            model.customView.removeFromSuperview()
        }
        
        pageHeaderModels.removeAll()
        selectTitleModels.removeAll()
    }
    
    /**
     添加所有TitleView
     */
    func addAllTitleViews() {
        var tag = 0
        for model in pageHeaderModels {
            contentTitleView.addSubview(model.customView)
            
            if model.customSize == .zero {
                unKnownWidthCount += 1
            }else {
                knownWidthCount += 1
                KnownWidth += model.customSize.width
            }
            
            if model.type != .Custom {  // 属于分页的自定义page
                model.customView.tag = tag
                selectTitleModels.append(model)
                
                model.customView.addTarget(self, action: #selector(clickPageTitleView(_:)), for: .touchUpInside)
                tag += 1
            }
        }
        
        self.delegate?.pageView(selectTitleModels)
        updateViewLayout()
    }
    
    /**
     重置HeaderModels
     */
    func resetPageHeaderModels(_ models: [FDMPageHeaderModel]) {
        removeAllTitleViews()
        pageHeaderModels = models
        
        addAllTitleViews()
        setIndex(0)
    }
}

