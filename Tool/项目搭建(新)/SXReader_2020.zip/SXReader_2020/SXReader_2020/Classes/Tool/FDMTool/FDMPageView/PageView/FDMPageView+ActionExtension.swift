//
//  FDMPageView+ActionExtension.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2020/12/21.
//

import UIKit

//MARK: - Action
extension FDMPageView {
    func setProgressDelegate() {
        delegate?.currentSelectIndex(index)
    }
    
    /**
     更新HeaderView高度
     */
    func updateHeaderViewHeight() {
        
        self.pageHeaderView.snp.updateConstraints { (make) in
            make.height.equalTo(titleHeight + animationHeight)
        }
        
        self.pageHeaderView.titleHeight = titleHeight
        self.pageHeaderView.animationHeight = animationHeight
    }
    
    /**
     重新添加所有子控制器
     */
    func readdChildControllers() {
        var childViews = [UIView]()
        
        for controller in childControllers {
            childViews.append(controller.view)
            target?.addChild(controller)
        }
        
        pageContentView.resetChildViews(childViews)
    }
    
    /**
     删除所有子控制器
     */
    func removeAllChildControllers() {
        // 删除控件
        self.pageContentView.removeAllChildViews()
        for controller in childControllers {
            controller.removeFromParent()
        }
        
        // 删除数据
        self.childControllers.removeAll()
    }
    
    /**
     重置控制器与子控制器
     
     - parameter target: 主控制器(用于添加子控制器)
     - parameter childControllers: 子控制器
     */
    func resetTarget(_ target: UIViewController, childControllers: [UIViewController]) {
        removeAllChildControllers()
        
        self.target = target
        self.childControllers = childControllers
        readdChildControllers()
    }
    
    /**
     添加标题
     */
    func resetHeaderModels(_ models: [FDMPageHeaderModel]) {
        pageHeaderView.resetPageHeaderModels(models)
    }
    
    /**
     设置Index
     */
    func setPageIndex(_ index: Int, animation: Bool) {
        self.index = index
        pageHeaderView.setIndex(index)
        pageContentView.setIndex(at: index, animation: animation)
    }
}
