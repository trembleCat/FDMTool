//
//  FDMTipsManager.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/2/22.
//

import UIKit

class FDMTipsManager: NSObject {
    static let shared = FDMTipsManager()
}

//MARK: - UI
extension FDMTipsManager {
    /**
     获取信息提示背景
     */
    func getMessageTipsBackDropView() {
        let tipsBackDropView = UIView()
        tipsBackDropView.backgroundColor = .white
        tipsBackDropView.layer.shadowColor = UIColor.black.cgColor
    }
}

//MARK: - ClassAction
extension FDMTipsManager {
    /**
     显示提示信息
     */
    class func showTipsMessage(_ message: String) {
        FDMTipsManager.shared.showTipsMessage(message)
    }
}

//MARK: - ObjectAction
extension FDMTipsManager {
    /**
     显示提示信息
     
     - parameter message: 提示信息
     - parameter duration: 持续时间
     */
    func showTipsMessage(_ message: String, duration: CGFloat = 2) {
        
    }
}
