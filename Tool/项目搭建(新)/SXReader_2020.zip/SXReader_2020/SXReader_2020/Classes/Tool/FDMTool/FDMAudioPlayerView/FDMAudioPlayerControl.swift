//
//  FDMAudioPlayerControl.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/1/7.
//

import UIKit

//MARK: - FDMAudioPlayerControlDelegate
protocol FDMAudioPlayerControlDelegate: NSObjectProtocol {
    func audioPlayerControl(_ audioControl: FDMAudioPlayerControl, clickPlayer sender: UIButton)
    func audioPlayerControl(_ audioControl: FDMAudioPlayerControl, clickLast sender: UIButton)
    func audioPlayerControl(_ audioControl: FDMAudioPlayerControl, clickNext sender: UIButton)
    func audioPlayerControl(_ audioControl: FDMAudioPlayerControl, clickCollection sender: UIButton)
    func audioPlayerControl(_ audioControl: FDMAudioPlayerControl, clickCatalog sender: UIButton)
    
    func audioProgressView(_ progressView: FDMProgressView, didDraggingProgressView currentValue: CGFloat)
}


//MARK: - 音频播放控制
class FDMAudioPlayerControl: UIView {
    
    weak var delegate: FDMAudioPlayerControlDelegate?
    
    let currentTimeLabel = UILabel()
    let totalTimeLabel = UILabel()
    
    let progressView = FDMProgressView()
    let progressControlView = UIView()
    let controlView = UIView()
    let subControlView = UIView()
    
    let playerBtn = UIButton()
    let lastSongBtn = UIButton()
    let nextSongBtn = UIButton()
    let collectionBtn = UIButton()
    let catalogBtn = UIButton()

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        createUI()
        createAction()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

//MARK: - UI
extension FDMAudioPlayerControl {
    func createUI() {
        self.addSubview(currentTimeLabel)
        self.addSubview(totalTimeLabel)
        self.addSubview(progressView)
        self.addSubview(playerBtn)
        self.addSubview(lastSongBtn)
        self.addSubview(nextSongBtn)
        self.addSubview(collectionBtn)
        self.addSubview(catalogBtn)
        
        /* 当前时间 */
        currentTimeLabel.text = "00:00"
        currentTimeLabel.textAlignment = .center
        currentTimeLabel.font = UIFont(name: "PingFangSC-Regular", size: 10)
        currentTimeLabel.textColor = .Hex("#333333")
        currentTimeLabel.snp.makeConstraints { (make) in
            make.left.equalToSuperview().offset(15)
            make.top.equalToSuperview().offset(5)
            make.width.equalTo(35)
            make.height.equalTo(20)
        }
        
        /* 总时间 */
        totalTimeLabel.text = "00:00"
        totalTimeLabel.textAlignment = .center
        totalTimeLabel.font = UIFont(name: "PingFangSC-Regular", size: 10)
        totalTimeLabel.textColor = .Hex("#333333")
        totalTimeLabel.snp.makeConstraints { (make) in
            make.right.equalToSuperview().offset(-15)
            make.top.equalToSuperview().offset(5)
            make.width.equalTo(35)
            make.height.equalTo(20)
        }
        
        /* 进度条 */
        progressView.delegate = self
        progressView.progressHeight = 6
        progressView.dragSpeed = 0.95
        progressView.totalProgressColor = .Hex("#E3E3E3")
        progressView.loadProgressColor = .clear
        progressView.currentProgressColor = .mainColor()
        progressView.snp.makeConstraints { (make) in
            make.left.equalTo(currentTimeLabel.snp.right)
            make.right.equalTo(totalTimeLabel.snp.left)
            make.centerY.equalTo(currentTimeLabel.snp.centerY)
            make.height.equalTo(25)
        }
        
        /* 播放暂停按钮 */
        playerBtn.setImage(UIImage(named: "audioPlayer_Player"), for: .normal)
        playerBtn.setImage(UIImage(named: "audioPlayer_Pause"), for: .selected)
        playerBtn.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(progressView.snp.bottom).offset(10)
            make.bottom.equalToSuperview().offset(-10)
            make.width.equalTo(playerBtn.snp.height)
        }
        
        /* 上一首 */
        lastSongBtn.setImage(UIImage(named: "audioPlayer_NormalLast"), for: .normal)
        lastSongBtn.setImage(UIImage(named: "audioPlayer_SelectedLast"), for: .highlighted)
        lastSongBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(playerBtn)
            make.right.equalTo(playerBtn.snp.left).offset(-35)
            make.width.height.equalTo(30)
        }
        
        /* 下一首 */
        nextSongBtn.setImage(UIImage(named: "audioPlayer_NormalNext"), for: .normal)
        nextSongBtn.setImage(UIImage(named: "audioPlayer_SelectedNext"), for: .highlighted)
        nextSongBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(playerBtn)
            make.left.equalTo(playerBtn.snp.right).offset(35)
            make.width.height.equalTo(30)
        }
        
        /* 收藏 */
        collectionBtn.setImage(UIImage(named: "audioPlayer_Collection"), for: .normal)
        collectionBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(playerBtn)
            make.centerX.equalTo(currentTimeLabel)
            make.width.height.equalTo(30)
        }
        
        /* 目录 */
        catalogBtn.setImage(UIImage(named: "audioPlayer_Catalog"), for: .normal)
        catalogBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(playerBtn)
            make.centerX.equalTo(totalTimeLabel)
            make.width.height.equalTo(30)
        }
    }
    
    /**
     创建进度条控制按钮
     */
    func createProgressControlView(withWH wh: CGFloat, centerWH: CGFloat) -> UIView {
        
        self.progressControlView.addSubview(controlView)
        controlView.backgroundColor = .white
        controlView.layer.cornerRadius = wh * 0.5
        controlView.layer.shadowColor = .Hex("#000000", alpha: 0.8)
        controlView.layer.shadowRadius = 5
        controlView.layer.shadowOpacity = 0.2
        controlView.layer.shadowOffset = .init(width: 0, height: 0)
        controlView.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
            make.width.height.equalTo(wh)
        }
        
        self.controlView.addSubview(subControlView)
        subControlView.backgroundColor = .mainColor()
        subControlView.layer.cornerRadius = centerWH * 0.5
        subControlView.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
            make.width.height.equalTo(centerWH)
        }
        
        return progressControlView
    }
}

//MARK: - Action
extension FDMAudioPlayerControl {
    func createAction() {
        /* 设置进度条 */
        progressView.setControlSubView(createProgressControlView(withWH: 14, centerWH: 10), size: .init(width: 25, height: 25))
        
        /* 设置按钮点击事件 */
        playerBtn.addTarget(self, action: #selector(clickPlayerBtn(_:)), for: .touchUpInside)
        lastSongBtn.addTarget(self, action: #selector(clickLastBtn(_:)), for: .touchUpInside)
        nextSongBtn.addTarget(self, action: #selector(clickNextBtn(_:)), for: .touchUpInside)
        collectionBtn.addTarget(self, action: #selector(clickCollectionBtn(_:)), for: .touchUpInside)
        catalogBtn.addTarget(self, action: #selector(clickCatalogBtn(_:)), for: .touchUpInside)
    }
    
    /**
     设置进度条控制器动画
     */
    func setProgressControlAnimation(isBegin: Bool) {
        var controlWidth: CGFloat = 0
        var subControlWidth: CGFloat = 0
        if isBegin { controlWidth = 20; subControlWidth = 14 }
        if !isBegin { controlWidth = 14; subControlWidth = 10 }
        
        UIView.animate(withDuration: 0.2) { [weak self] in
            self?.controlView.layer.cornerRadius = controlWidth * 0.5
            self?.controlView.snp.updateConstraints { (make) in
                make.width.height.equalTo(controlWidth)
            }
            
            self?.subControlView.layer.cornerRadius = subControlWidth * 0.5
            self?.subControlView.snp.updateConstraints { (make) in
                make.width.height.equalTo(subControlWidth)
            }
            
            self?.progressControlView.layoutIfNeeded()
        }
    }
    
    /**
     点击播放按钮
     */
    @objc func clickPlayerBtn(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected
        
        self.delegate?.audioPlayerControl(self, clickPlayer: sender)
    }
    
    /**
     点击上一首
     */
    @objc func clickLastBtn(_ sender: UIButton) {
        self.delegate?.audioPlayerControl(self, clickLast: sender)
    }
    
    /**
     下一首
     */
    @objc func clickNextBtn(_ sender: UIButton) {
        self.delegate?.audioPlayerControl(self, clickNext: sender)
    }
    
    /**
     点击收藏
     */
    @objc func clickCollectionBtn(_ sender: UIButton) {
        self.delegate?.audioPlayerControl(self, clickCollection: sender)
    }
    
    /**
     点击目录
     */
    @objc func clickCatalogBtn(_ sender: UIButton) {
        self.delegate?.audioPlayerControl(self, clickCatalog: sender)
    }
}

//MARK: - FDMProgressViewDelegate
extension FDMAudioPlayerControl: FDMProgressViewDelegate {
    func progressView(_ progressView: FDMProgressView, didDraggingProgressView currentValue: CGFloat) {
        self.delegate?.audioProgressView(progressView, didDraggingProgressView: currentValue)
    }
    
    func progressView(_ progressView: FDMProgressView, didTouchBeginDragView currentValue: CGFloat) {
        setProgressControlAnimation(isBegin: true)
    }
    
    func progressView(_ progressView: FDMProgressView, didTouchEndDragView currentValue: CGFloat) {
        setProgressControlAnimation(isBegin: false)
    }
}
