//
//  FDMBaseExtension.swift
//  SXReader_2020
//
//  Created by 发抖喵 on 2021/1/5.
//

import UIKit

extension Double {
    /**
     四舍五入保留 places 位值
     */
    func roundTo(places: Int) -> Double {
        let divisor = pow(10.0,Double(places))
        return (self * divisor).rounded() / divisor
    }
}
